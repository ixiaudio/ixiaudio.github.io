ixiQuarks for windows (based on swingOSC)


How to install it :

- Download and install Java (used by the ixiQuarks interface)
http://www.java.com/en/download/manual.jsp

- Download and install Psycollider
http://sourceforge.net/project/showfiles.php?group_id=54622&package_id=133499

- copy the files from SCClassLibrary folder provided into C:\Program Files\Psycollider\SCClassLibrary 

- copy the files from plugins folder provided into C:\Program Files\Psycollider\plugins

- copy the preferences folder provided to C:\Program Files\Psycollider

- replace the C:\Program Files\Psycollider\startup.sc with the startup.sc provided

- create a new folder called "ixiquarks" in C:\Program Files\Psycollider\sounds

- run Psycollider for first time. it will ask you to locate in the hardrive the SCClassLibrary, which
should be in C:\Program Files\Psycollider\



(Optional step) if you want to use the latest version of SwingOSC: 
- download latest version of SwingOSC from http://sourceforge.net/projects/swingosc
- copy SwingOSC\build\SwingOSC.jar to C:\Program Files\Psycollider\SwingOSC\build
- replace C:\Program Files\Psycollider\SCClassLibrary\SwingOSC with SwingOSC\SuperCollider\SCClassLibrary\SwingOSC





Running ixiQuarks :

- Just run Psycollider. ixiQuarks should open up few secs after together with the 
"Psycollider Post Window" and "localhost server" panel.


Quitting :
- Close the Psycollider Post Window, this quits ixiQuarks, Psycollider and the "localhost server" panel.




Troubbleshotting:

- Some firewalls might want to block ixiQuarks, so you might need to give permissions to run 
to the processes that open ixiQuarks. This is : scsynth.exe, psycollider.exe and java.exe.

- if your system is slow and the default 5 seconds wait are not enough for the SC server to start
you might need to increase the value of the last line in the startup.sc file .
{ XiiQuarks.new; }.defer(5);
Increase the number 5 to a higher value. This will increase the number of seconds that Psycollider
waits to launch ixiQuarks.

- if you want to restart ixiQuarks you can just press ALT+K or in the Psycollider Post Window, in 
the Lang menu choose "Compile Library" option.

- Selecting your sound card :
edit the startup.sc file to add your sound card in a line like the one below editing the text inside
the quotations marks. When the server starts up it prints in the Psycollider Post Window all sound
devices detected, check there your devices.
s.options.device_("MME : Realtek AC97 Audio");


- make sure that in the "localhost server" panel it says "running" in green letters. If you see 
"inactive" in grey letters press the "Boot" button on the top left. You should see in the 
"Psycollider Post Window" something like this output below. Otherwise there might be a problem with 
the Psycollider installation.

> booting 57110
> Using vector unit: no

> Device options:
>  - MME : Microsoft Sound Mapper - Input   (device #0 with 2 ins 0 outs)
>  - MME : SoundMAX Digital Audio   (device #1 with 2 ins 0 outs)
>  - MME : Microsoft Sound Mapper - Output   (device #2 with 0 ins 2 outs)
>  - MME : SoundMAX Digital Audio   (device #3 with 0 ins 2 outs)

> Booting with:
> 	In: MME : SoundMAX Digital Audio 
> 	Out: MME : SoundMAX Digital Audio 
> suggestedLatency used: 0.200
> SuperCollider 3 server ready..
> notification is on 

- if the Psycollider Post Window closes but the server panel and ixiQuarks window stays open, you
need to force to quit both to restart. Check in the process window (CTL+ALT+DEL) that scsynth.exe and 
java.exe are not running, otherwise kill them.




TO DO :
Bigger size for channel selection pulldown menus
output/input wav files instead of aiff
