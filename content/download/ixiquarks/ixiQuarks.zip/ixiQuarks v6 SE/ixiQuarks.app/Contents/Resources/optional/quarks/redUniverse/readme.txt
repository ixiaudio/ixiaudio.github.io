//--
work in progress.  happy for any comments or contributions.

note! if you run LINUX, WINDOWS or just prefer to use SwingOSC over Cocoa, you'll need to uncomment all the code in the file RedJWindow.sc and recompile.

some of the examples require additional classes like RedGA, RedLSystem etc.  these are available online at my homepage http://www.fredrikolofsson.com under code->sc


//--
080219 - updated for sc3.2 and swingosc0.59
	fixed all pendulum examples to draw line on swingosc (added a GUI.pen.stroke)
	changed from mouseover to mousemove so now it's required to click&drag to update mouse position.
	fixed 150-track_synth.scd and took away RedTrack.  now using only standard ugens for audio tracking.
080116 - changed from 25 to 40 fps for RedWindow and RedJWindow .play
	some small corrections to match Pen changes to width_
071205 - converted all help.rtf to .html and the examples to .scd
	added the example overview file.
	changed so that RedJWindow is disabled by default.
071031 - update for 3.1
	removed penExt.sc with its strokeColor_ and fillColor_ extensions.
	tiny fix for 150-track_synth.rtf.
071029 - bugfix
	now RedWindow shouldn't crash sc anymore.  it was due to scott's window scoll implemented earlier this autumn.

