
XixiHID by ixi software

www.ixi-software.net

v 0.1 - 16th of September, 2005



Installation:

Put the XixiHID.sc file into the SCClassLibrary folder of SuperCollider
and the XixiHID.help.rtf file into the Help folder.

Trash this file and...

Enjoy!
