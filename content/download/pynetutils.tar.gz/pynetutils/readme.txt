pynetutils for python and pure data
v 0.2 december 2008

-- Contact --
enrike@ixi-audio.net 
any type of feedback and/or contributions are welcome


--- License --- GPL
This library is free software; you can redistribute it and/or modify it under the terms 
of the Lesser GNU, General Public License as published by the Free Software Foundation.

This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this library;
 if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 MA 02111-1307 USA


--- System requirements ---
pynetiutils is a set of PureData abstractions and Python scripts. 

If you use it from Python you need to have python installed Python  (probably python 2.5) 
http://www.python.org

If you use it from PureData you also need Puredata Extended 0.40.3 
http://puredata.org/downloads 
Under Linux you might need to compile py from source 
http://puredata.info/Members/thomas/py

In all systems you might need to add py external to PD startup. To do this go to File > startup > new there add "py" save and restart PD. On mac this is on puredata > preferences > startup

-- Description --
pynetiutils is a set of PureData abstractions and Python scripts to access information from the internet about the weather, download images, and also about the location of the computer.  It also includes a script to search xml files for keys.

-- Content --
For the Python version you just need scripts.py and searchxml.py (with data.xml)
For the Pure Data version you need everything.

-- Python module functions --

searchxml.py module :

search( st = 'tag1' ) :
    readsa file called data.xml and searchs for items with ST on tag .  returns a list with the content of the node <name>
    The format of the xml file 	is :
<files>
<file>
<name>archivo1.avi</name>
<tag>tag1</tag>
<tag>tag2</tag>
</file>
</files>

scripts.py module :

BBCWeather( city = 'bilbao' ) 
   ->  {'Temperature': '20', 'Wind Direction': 'N/A', 'Relative Humidity': '78',
    'Pressure': '1023', 'Visibility': 'Moderate', 'Falling': None, 'Wind Speed': '0'}

autoBBCWeather ()
	Same as before but it tries to find out where the computer is located in the world.

yahooWeather( zip_code='SPXX0016' ) :
    returns [ data, low temp, hight tem, condition ] from yahoo weather
    takes yahoo ID for city

externalIP() :
	returns the external (internet) IP of the machine

localIP() :
	returns the local network IP of the machine

geoInfo() :
	returns a dictionary with geoinfo produced from maxmind.com web page from 	computer's IP. Dictionaty format is :
	{
        'code' : str,
        'country' : str,
        'city' : str,
        'region' : int,
        'region_name' : str,
        'latitude' : float,
        'longitude' : float,
        'postal_code' : str,
        }    

googleImgs( word = 'txakoli', maxnum = 10, dest = 'images' ) :
	tries to download to a folder called 'images' the first matches on google images for the 	given key word


-- Pd objects --
Check the scripts_examples.pd search.pd examples provided
The objects just wrap the python functions explained above so they have same functionality, they are well explained in those examples.