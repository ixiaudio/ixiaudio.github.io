	
try:
    import pyext
    from time import sleep
except:
    print "ERROR: This script must be loaded by the PD/Max pyext external"

try :
    import searchxml
except :
    print '--> searchxml.py missing !!'



    
class search( pyext._class ) :
    _inlets = 1
    _outlets = 1

    def __init__(self) : self._detach(True)

    def _anything_1( self, st ) :
        try :
            st = str( st ) #  try to convert
            files = searchxml.search( st )
        except :
            print "cannot search for", st
            self._outlet( 1, 0 )
            return

        if files == [] :
            self._outlet(1, 'no matches!') # nothing found
        else :
            for n in files :
                self._outlet( 1, n )
            
        
