import xml.dom.minidom
import urllib, os

# document =
"""\
<files>

<file>
<name>archivo1.avi</name>
<tag>tag1</tag>
<tag>tag2</tag>
</file>

<file>
<name>archivo2.avi</name>
<tag>tag1</tag>
<tag>tag2</tag>
<tag>tag3</tag>
</file>

</files>
"""

def search( st = 'tag1' ) :
    """ reads data XML file and searchs for items with ST on tag 
    """
    print 'searching for : ', st

    results = [] # to add matching names

    p = os.path.join( os.getcwd(),  'data.xml' )
    
    if not os.path.isfile(p) :
        print 'file %s does not exist' % f
        return
    
    f = open( p, 'rU' )
    
##    dom = xml.dom.minidom.parseString( f )
    dom = xml.dom.minidom.parse( f )

    def getText(nodelist):
        rc = ""
        for node in nodelist:
            if node.nodeType == node.TEXT_NODE:
                rc = rc + node.data
        return rc
        
    slides = dom.getElementsByTagName( 'file' ) # all

    for slide in slides :
        name = slide.getElementsByTagName( 'name' )[0]
        thisname = getText( name.childNodes )
        
        tags = slide.getElementsByTagName( 'tag' )
        for tag in tags :
            if getText( tag.childNodes ) == st :
                results.append( str( thisname ) ) # str to get rid of 'u' as in --> u'archive1.avi'

    return results



if __name__ == '__main__' :
    print search()
