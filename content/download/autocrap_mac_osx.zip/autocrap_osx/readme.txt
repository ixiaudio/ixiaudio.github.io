
:::::::::::::::::::::::::::::  - ixi software -  ::::::::::::::::::::::::::::::::::

Autocrap [public beta v0.1]             - 25th of April, 2004.

Autocrap is a sampling machine that is listening to the sound in of your computer. It records it into some buffers that are played creating various layers of sounds. The pitch and panning of the sound depends on the movement of a random object that keeps wandering around on screen and you can interact with.

You can change the lenght of the buffers, the number of layers and several other parameters. So plug your instrument or a mic into your machine, set some values in the boxes, press space to start recording and have fun.

Shortcuts:
Press space bar to start recording
Move the numbers in the boxes to set the lenght of the timers
Right click on the numbers to set the timer off
Click on the layer numbers to se the layers on or off
Click on the stage to control de movement of the object.


Play around with the prefs file in the prefs folder to set different sizes of the app.


if you have any feedback for us please email info@ixi-software.net