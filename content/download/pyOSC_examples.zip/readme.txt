simple examples by www.ixi-audio.net of usage for pyOSC library 
https://trac.v2.nl/wiki/pyOSC

