/* Copyright (c) 1997-1999 Miller Puckette.
* For information on usage and redistribution, and for a DISCLAIMER OF ALL
* WARRANTIES, see the file, "LICENSE.txt," in this distribution.  */

void pdgui_vmess(char *fmt, ...);
void pdgui_mess(char *s);

void pdgui_evalfile(char *s);

#define GUISTRING 1000
