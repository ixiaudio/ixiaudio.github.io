The "audio playpen" is intended as a collection of analog-style modules
for people who just want to patch stuff together without worrying much
about how Pd works.  A fair amount of work would be needed to make this into
a more usable package than it is now.  At the moment it's unclear what
should be the relationship between this collection, the "examples," and
the "tools".

At the very least there should be oscillators and envelope generators here,
and audio-rate db/rms/dB, mtof, ftom conversion...
