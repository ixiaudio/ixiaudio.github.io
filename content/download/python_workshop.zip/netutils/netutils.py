
import urllib
from xml.dom import minidom
###################
import urllib2
###################
import os, re  #, urllib, urllib2


# full forecast
# http://weather.yahoo.com/forecast/SPXX0016_c.html
# XML reduced forecast
# http://xml.weather.yahoo.com/forecastrss?p=SPXX0016&u=c
# Records & Averages
# http://weather.yahoo.com/climo/SPXX0016_c.html

WEATHER_URL = 'http://xml.weather.yahoo.com/forecastrss?p=%s&u=%s'
WEATHER_NS = 'http://xml.weather.yahoo.com/ns/rss/1.0'

###################

# this returns the remote IP of the computer
URL = 'http://www.whatismyip.org/'
# this returns a string with geoinfo 
URL2 = 'http://j.maxmind.com/app/geoip_city'
##URL2 = 'http://www.maxmind.com/app/javascript_city'
IP = None # to avoid requesting external IP too many times to server.




###########################
## BBC weather
###########################

def autoBBCWeather () :
    city = geoInfo()[ 'city' ]
    print city
    return BBCWeather( city )

def BBCWeather( city = 'bilbao' ) :
    """ {'Temperature': '20', 'Wind Direction': 'N/A', 'Relative Humidity': '78',
    'Pressure': '1023', 'Visibility': 'Moderate', 'Falling': None, 'Wind Speed': '0'}
    """
    url = 'http://www.bbc.co.uk/cgi-perl/weather/search/new_search.pl?x=0&amp;y=0&amp;search_query=%s' % city
    # http://www.bbc.co.uk/cgi-perl/weather/search/new_search.pl?x=0&y=0&search_query=bilbao

    f = _getURL( url )
    data = f.read()
    
    if 'No locations were found for' in data :
##        print 'COULT NOT GET DATA FOR YOUR LOCATION'
        return 'error : No locations were found for %s' % city
    
    match = 'world='
    n = data.find( match ) + len( match )
    code = ''
    for i in range( n, n+10 ) :
        if data[i] != '"' :
            code += str( data[i] )
        else :
            break

    xmlurl = 'http://feeds.bbc.co.uk/weather/feeds/rss/obs/world/%s.xml' % code
    f = _getURL( xmlurl )
    data = f.read()

    try :
        dom = minidom.parse( urllib.urlopen( xmlurl)  ) # data )
    except :
        print 'error parsing data'

    for n in dom.getElementsByTagName(  'item' )[0].childNodes :
        if n.nodeName == 'description' :
            des = n.childNodes[0].data

    all = {}
    des = des.split( ',' ) 
    for d in des :
        a = d.split( ':' )
        key = str(a[0]).strip() # get rid of unicode symbol and whitespaces: u' 1021mB' --> '1021mB'
        
        if key == 'Temperature' :
            a[1] = a[1][:3] # in this case extract the first 3 items which are whitespace+temperature in two digits
        elif key == 'Relative Humidity' :
            a[1] = a[1].strip( '%' )
        elif key == 'Wind Speed' :
            a[1] = a[1].strip(' mph')
        elif  key == 'Pressure' :
            a[1] = a[1].strip('mB')
        
        if len(a) == 2 :
            all[key] = str(a[1]).strip()
        else :
            all[key] = None

    return all


#############
# yahoo weather
#############


def yahooWeather( zip_code='SPXX0016' ) :
    """ returns [ data, low temp, hight tem, condition ] from yahoo weather
    takes yahoo ID for city

    <yweather:location city="Bilbao" region=""   country="SP"/>

    <yweather:units temperature="C" distance="km" pressure="mb" speed="kph"/>
    <yweather:wind chill="18"   direction="100"   speed="4.83" />
    <yweather:atmosphere humidity="88"  visibility="7"  pressure="0"  rising="0" />
    <yweather:astronomy sunrise="6:33 am"   sunset="9:56 pm"/>

    <geo:lat>43.26</geo:lat>
    <geo:long>-2.93</geo:long>

    <yweather:forecast day="Wed" date="25 Jun 2008" low="16" high="23" text="Partly Cloudy" code="30" />
    <yweather:forecast day="Thu" date="26 Jun 2008" low="17" high="26" text="Partly Cloudy" code="30" />

    """
    scale = 'c' # "c" for celsious, "f" for farenheit
    
    url = WEATHER_URL % ( zip_code, scale )
    dom = minidom.parse( urllib.urlopen(url) )

    condition = dom.getElementsByTagNameNS( WEATHER_NS, 'condition' )[0]
    cond = str( condition.getAttribute( 'text' ) )
    temp = str( condition.getAttribute( 'temp' ) )

    wind = dom.getElementsByTagNameNS( WEATHER_NS, 'wind' )[0]
    chill = str( wind.getAttribute( 'chill' ) )
    direction = str( wind.getAttribute( 'direction' ) )
    speed = str( wind.getAttribute( 'speed' ) )

    atmosphere = dom.getElementsByTagNameNS( WEATHER_NS, 'atmosphere' )[0]
    humidity = str( atmosphere.getAttribute( 'humidity' ) )
    visibility = str( atmosphere.getAttribute( 'visibility' ) )
    pressure = str( atmosphere.getAttribute( 'pressure' ) )
    rising = str( atmosphere.getAttribute( 'rising' ) )

    astronomy = dom.getElementsByTagNameNS( WEATHER_NS, 'astronomy' )[0]
    sunrise = str( astronomy.getAttribute( 'sunrise' ) )
    sunset = str( astronomy.getAttribute( 'sunset' ) )
    
    return {
        'condition' : cond,
        'temperature' : temp,
        'wind' : { 'chill' : chill, 'temp' : temp, 'speed' : speed },
        'atmosphere' : { 'humidity' : humidity, 'visibility' : visibility, 'pressure' : pressure, 'rising' : rising },
        'astronomy': { 'sunrise' : sunrise, 'sunset' : sunset }
        }
        



#######################
## IP
#######################
def _getURL( url ) :
    try :
        opener = urllib2.build_opener()
        opener.addheaders = [ ( 'User-agent', 'Mozilla/5.0' ) ]
        return opener.open( url )
    except :
        print '--> error opening URLs'
        return

def externalIP() :
    global IP
    if not IP or IP == '' :
        f = _getURL( URL )
        ip = f.read()
        
        if 'Error' in ip :
            print ip ## print error
            return None
        else :
            IP = ip

    return IP

def localIP() :
    from socket import socket, SOCK_DGRAM, AF_INET
    s = socket( AF_INET, SOCK_DGRAM )
    try :
        s.connect( ('google.com', 0) )
    except :
        print 'netutils.localIP() error : could not resolve google.com URL'
    return s.getsockname()[0]

    
def geoInfo() :
    """ returns dict with geoinfo produced from maxmind.com web page from computer's IP
    """
##    this string below is the format of the data returned by http://j.maxmind.com/app/geoip_city
##    data =  "\
##    function geoip_country_code() { return 'ES'; } \
##    function geoip_country_name() { return 'Spain'; } \
##    function geoip_city() { return 'Bilbao'; } \
##    function geoip_region() { return '59'; } \
##    function geoip_region_name() { return 'Pais Vasco'; } \
##    function geoip_latitude() { return '43.2500'; } \
##    function geoip_longitude() { return '-2.9667'; } \
##    function geoip_postal_code() { return ''; } 
##    "
    
    f = _getURL( URL2 )
    data = f.read()

    sp = data.split( "'" ) # split depending on single '' quotations marks to get words like 'Bilbao'
    
    return {
        'code' : sp[1],
        'country' : sp[3],
        'city' : sp[5],
        'region' : int( sp[7] ),
        'region_name' : sp[9],
        'latitude' : float( sp[11] ),
        'longitude' : float( sp[13] ),
        'postal_code' : sp[15],
        }     



###############################
## google images
###############################

def googleImgs( word = 'txakoli', maxnum = 10, dest = 'images' ) :
    
    print 'searching google for images under : ', word
    print 'max num of images to download : ', maxnum
    print 'destination folder is : ', dest

    if not os.path.isdir( dest ) : # if not there create it
        print 'images directory wasnt there, creating it'
        os.mkdir( os.path.join( os.getcwd(), dest ) )
    
    urllist = []
    data = 0
    url_regexp = unicode( r"((http|ftp)://)?(((([\d]+\.)+){3}[\d]+(/[\w./]+)?)|([a-z]\w*((\.\w+)+){2,})([/][\w.~]*)*)" )
##            ret='<div id="rand_img"><b>'+word+'!!</b><br />'
    URL = 'http://images.google.com/images?ie=ISO-8859-2&q=' + word + '&lr=&sa=N&tab=wi'
        
    try :
        opener = urllib2.build_opener()
        opener.addheaders = [ ( 'User-agent', 'Mozilla/5.0' ) ]
        f = opener.open( URL )
        data = f.read()    
    except :
        print '--> error opening URLs'
    
    for m in re.finditer( url_regexp, data ) :
        if re.search( '([jJ][pP][gG]|[pP][nN][gG]|[gG][iI[fF])$', m.group() ) :
            urllist.append( m.group() )
            
    names = []

    for i, imgurl in enumerate( urllist[ :maxnum ] ) :
        name = imgurl.split( '/' )[-1] # last one
        
        dest = os.path.join( os.getcwd(), dest, name )

        try :
            urllib.urlretrieve( imgurl,  dest )
            names.append( name )
        except :
            print '--> tried but could not retrieve : ' , imgurl
            
##        sleep(0.1) # return control to PD temporarily
        print 'trying next one ...'
        
    print '--> DONE with %i image(s)' % len( names )
    return names
        

        


if __name__ == '__main__' :
    ## yahoo weather ##
    print "BBCWeather guessing where we are :", autoBBCWeather()
    print "BBCWeather for london : ", BBCWeather( 'london' )
    print "YahooWeather for bilbao : ", yahooWeather( 'SPXX0016' ) # yahoo ID for bilbao
##    ## IP ##
    print "*"*20
    print 'external IP : ', externalIP()
    print 'local IP : ',  localIP()
    print 'automatic geoinfo : ', geoInfo()
##    ## google images ##
    print "*"*20
    imgs = googleImgs()
    print 'downloaded', imgs
    
