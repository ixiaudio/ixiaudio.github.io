from pyprocessing import *




def setup() :
    size(800, 600)
    hint(DISABLE_DEPTH_TEST)



    
def mousePressed() :
    print "mouse pressed currently at", mouse.x, mouse.y

def mouseClicked() :
    print "mouse clicked. when mouse is pressed and later released"

def mouseReleased() :
    print "mouse released"

def mouseDragged() :
    print "mouse dragged"

def mouseMoved() :
    print "mouse moved"
    
def keyPressed():
    print "key pressed ", key.char, key.code


def draw():
    background(255) # clear screen buffer

    if not mouse.pressed : # different rect colors depending on mouse button pressed
        fill(0,10, 255) 
        stroke(255, 0, 0) 
    elif mouse.button == LEFT:
        noStroke()
        fill(255, 10, 0) 
    elif mouse.button == RIGHT :
        fill(0,255, 255) 
    
    rect(mouse.x, mouse.y, 250,100)




run()

