from pyprocessing import *

import OSC, netutils, threading


oldx = 0
oldy = 0
newx = 0
newy = 0


def newLoc(addr, tags, stuff, source) :
    print stuff
    global oldx, oldy, newx, newy
    oldx = newx # store prev position
    oldy = newy
    newx = stuff[0] # and now get new pos
    newy = stuff[1]



OSC.initServer( netutils.localIP(), 9001 )
OSC.setHandler("/draw", newLoc)

# just checking which handlers we have added
OSC.reportHandlers()


brushsize= 1
red = 0
green = 0
blue = 0






# for displaying on screen the values
font = createFont("Times New Roman", 20)
textFont(font)
textAlign(CENTER,CENTER)
        


def setup() :
    size(800, 600) # canvas size
    hint(DISABLE_DEPTH_TEST)

    background(255) # bg color on start
    stroke(red, green, blue) # brush color
    strokeWeight(brushsize) # thinkness of brush
    
    smooth()# or noSmooth()






def draw():
    #background(255) # In this case we dont clear the buffer every loop to accumulate the previous drawings

    if key.pressed :
        #print "key pressed ", key.char, key.code
        global brushsize, red, green, blue # must declare globals when modifying its values

        # change thickness on arrown up/down pressed #
        if key.code == UP : 
            brushsize += 1
        elif key.code == DOWN : 
            brushsize -= 1

        if (brushsize < 1) : brushsize = 1 # set lower limit to avoid errors
        
        strokeWeight(brushsize) # ok, so set thinkness of brush
        
        # change smoth mode #
        if key.char == "a" : # smooth
            smooth()
        elif key.char == "s" :
            noSmooth()

        # change brush color #
        elif key.char ==  "q" : # up
            red += 5
        elif key.char == "w" : # down
            red -= 5
            
        elif key.char == "e" : # up
            green += 5
        elif key.char == "r" : # down
            green -= 5
            
        elif key.char == "t" : # up
            blue += 5
        elif key.char == "y" : # down
            blue -= 5
            
        #set limits to color. does not produce an error but it is nicer to have
        if red < 0 : red = 0
        elif red > 255 : red = 255
        if green < 0 : green = 0
        elif green > 255 : green = 255
        if blue < 0 : blue = 0
        elif blue > 255 : blue = 255
        
        stroke(red, green, blue) # ok, so set color

        if key.char == " " : # space clears screen
            background(255)
            
        print brushsize, red, green, blue

        

    # display the current settings on screen #

    txt = "size: %i / red: %i / green: %i / blue: %i" % ( brushsize, red, green, blue ) # this way we introduce the value of the variables into the text
    text(txt, 20, 20) 

##    if mouse.pressed : # draw a line from current mouse position to mouse position in previous frame
##        line(pmouse.x, pmouse.y, mouse.x, mouse.y)
    line(oldx, oldy, newx, newy)
    



run()

OSC.close()

