from pyprocessing import *



def setup() :
    size(800, 600)
    hint(DISABLE_DEPTH_TEST)


def draw():
    background(255)

    if not mouse.pressed : # if mouse is pressed down draw anything
        
        fill(0,10, 255) # fill color
        stroke(255, 0, 0) # stroke color
        ellipse(100, 500, 100, 100) # Circle -> x,y,w,h

        noStroke() # No stroke line in subsequent drawing functions until stroke is set again
        
        fill(255, 10, 0) 
        rect(400, 100, 250,100) # Rect

        fill(0, 100, 50) 
        arc(450, 55, 50, 50, 0, PI/2) # Arc
        noFill() # no subsequent fill in drawing functions until fill is set again
        arc(450, 155, 60, 60, PI/2, PI) #Arc
        
        fill(0, 255, 50) 
        triangle( 100, 400, 300, 350, 10, 200) # Triangle

        stroke(0, 150,150)
        line(100,20, 120,300) # Line

        stroke(0, 150, 0)
        font = createFont("Times New Roman", 20)
        textFont(font); 
        textAlign(CENTER,CENTER)
        text("The quick brown\nfox jumps over\nthe lazy dogs", 550, 300) # Text

        stroke(150, 150, 0)
        fill(150, 155, 250) 
        beginShape() # Shape. by vertexes
        vertex(300, 400)
        vertex(350, 410)
        vertex(320, 500)
        vertex(290, 520)
        vertex(250, 420)
        endShape(CLOSE)

        bezier(30, 20,  80, 5,  80, 75,  30, 75) # Bezier curve

        stroke(255, 102, 0);
        curve(373, 14, 373, 81, 315, 65, 315, 5) # Curve

        img = loadImage("images/arch.jpg") # Image
        image(img, 600, 400);





run()

