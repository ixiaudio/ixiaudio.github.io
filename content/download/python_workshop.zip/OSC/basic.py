import OSC
import threading


basic_client = 0
basic_server = 0
st = 0


def printing_handler(addr, tags, data, source):
    print "---"
    print "received new osc msg from %s" % OSC.getUrlStr(source)
    print "with addr : %s" % addr
    print "typetags :%s" % tags
    print "the actual data is : %s" % data
    print "---"



def initClient(ip='127.0.0.1', port=9000) :
    global basic_client
    basic_client = OSC.OSCClient()
    basic_client.connect( (ip,port) )
    
def initServer(ip='127.0.0.1', port=9001, mode=0) :
    """ mode 0 for basic server, 1 for threading server, 2 for forking server
    """
    global basic_server, st

    if mode == 0 :
        basic_server = OSC.OSCServer( (ip ,port) ) # basic
    elif mode == 1 : 
        basic_server = OSC.ThreadingOSCServer( (ip ,port) ) # threading
    elif mode == 2 :
        basic_server = OSC.ForkingOSCServer( (ip ,port) ) # forking

    basic_server.addDefaultHandlers()
    st = threading.Thread( target = basic_server.serve_forever )
    st.start()

def setHandler(address="/print", hd=printing_handler) :
    basic_server.addMsgHandler(address, hd) # adding our function

def close() :
    if basic_client is not 0 : basic_client.close()
    if basic_server is not 0: basic_server.close() 
    if st is not 0: st.join()

def reportHandlers() :
    print "Registered Callback-functions are :"
    for addr in basic_server.getOSCAddressSpace():
        print addr
    
def sendMsg( address='/print', data=[] ) :
    m = OSC.OSCMessage()
    m.setAddress(address)
    for d in data :
        m.append(d)
    basic_client.send(m)

def createBundle() : # just for api consistency
    return OSC.OSCBundle()

def sendBundle(b):
    basic_client.send(b)

def createMsg(address='/print', data=[]) :
    m = OSC.OSCMessage()
    m.setAddress(address)
    for d in data :
        m.append(d)
    return m
