"""     HIDserver 0.2
    ixi software - 2007
    www.ixi-software.net
	
	modification September 2007 by Marije Baalman - nescivi - www.nescivi.nl

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
     General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


#######################################
description :
HID OSC server is a SDL based python app that sends out via OSC any HID device (gamepad, joystick)
event generated data.

usage :
just run the app, you can pass the following arguments : ip, port, rate, verbose
the default values are : ip = "127.0.0.1", port = 57120, rate=12, verbose=0
to quit just close the server window

description of OSC messages sent by the server :
    - adress : /hid
    - value :
    INIT event : [ 'running', joysticklist] # joysticklist is None if no joystick is found 
    QUIT event : [ 'quit' ]
    JOYAXISMOTION event : [ 'axismotion', joystickID, axis, value ]
    JOYBALLMOTION event : [ 'ballmotion',  joystickID, ball, value ]
    JOYHATMOTION event : [ 'hatmotion',  joystickID, hat, value ]
    JOYBUTTONDOWN event : [ 'buttondown', joystickID, button ]
    JOYBUTTONUP event : [ 'buttonup', joystickID, button ]
#########################################
    
"""


import osc, pygame, os, sys
from pygame.locals import *


def load_image(name, colorkey=None):
    try:
        image = pygame.image.load(name)
    except pygame.error, message:
        print 'cannot load image:', name
        raise SystemExit, message

    image = image.convert()

    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0,0))
        image.set_colorkey(colorkey, RLEACCEL)

    return image#, image.get_rect()




def main( ip = "127.0.0.1", port=57120, rate=12, verbose=0 ) : ##        ( *args, **kwds):
    ip = str(ip) 
    port = int(port)
    rate = int(rate)
    verbose = int(verbose)
    
    pygame.init()
    osc.init()

    ## Pygame window #################
    screen = pygame.display.set_mode((120, 80), HWSURFACE | DOUBLEBUF)
    pygame.display.set_caption('HID OSC server v0.2')
    pygame.mouse.set_visible(1) #mouse invisible

    img = load_image('ixi_logo.gif', -1)
    icon = pygame.transform.scale(img, (32, 32))
    pygame.display.set_icon(icon)

    background = pygame.Surface(screen.get_size())
    background = background.convert()
    background.fill((255, 255, 255)) #bg color
    screen.blit(background, (0,0))

    #Display ixi logo
    img = pygame.transform.scale(img, (screen.get_size()[0]-6, screen.get_size()[1]-6))
    screen.blit(img, (3,3))
    pygame.display.flip()

    #################################

    try: # init joystick
        joy = []
        sticks = []
        pygame.joystick.init() # init main joystick device system
        for n in range(pygame.joystick.get_count()): #
            stick = pygame.joystick.Joystick(n)
            stick.init() # init instance
            # report joystick charateristics #
            print '-'*20
            print 'Enabled HID device: ' + stick.get_name()
            print 'it has the following devices :'
            print '--> buttons : '+ str(stick.get_numbuttons())
            print '--> balls : '+ str(stick.get_numballs())
            print '--> axes : '+ str(stick.get_numaxes())
            print '--> hats : '+ str(stick.get_numhats())
            print '-'*20
            joy.append(stick.get_name())
            sticks.append(stick)
    except pygame.error:
        print 'no HID device found.'
        joy = 'False'

    clock = pygame.time.Clock()

    print 'HID server : ready to send HID events via ip %s, port %i, %i times per sec, verbose %i' % (ip, port, rate, verbose)

    go = 1

    #print '%s' % (joy)

##    counter = 0
##    for n in sticks:
    for counter, n in enumerate(sticks) :
        #print '%s' % n.get_name()
        osc.sendMsg("/hid", [ 'running', n.get_name(), counter ],  ip, port)
        osc.sendMsg("/hid", [ counter, 'axes', n.get_numaxes()], ip, port )
        osc.sendMsg("/hid", [ counter, 'balls', n.get_numballs()], ip, port )
        osc.sendMsg("/hid", [ counter, 'hats', n.get_numhats()], ip, port )
        osc.sendMsg("/hid", [ counter, 'buttons', n.get_numbuttons()], ip, port )
##        counter = counter + 1

##        clock.tick(100) # fps

    while go :
        clock.tick(rate) # fps

        for e in pygame.event.get() :
            if e.type == JOYAXISMOTION: # 7
                osc.sendMsg("/hid", [ 'axismotion', e.joy, e.axis, e.value ],  ip, port) # JOYAXISMOTION
            elif e.type == JOYBALLMOTION: # 8
                osc.sendMsg("/hid", [ 'ballmotion', e.joy, e.ball, e.value ],  ip, port) # JOYBALLMOTION
            elif e.type == JOYHATMOTION: # 9
               osc.sendMsg("/hid", [ 'hatmotion', e.joy, e.hat, e.value ],  ip, port) # JOYHATMOTION
            elif e.type == JOYBUTTONDOWN: # 10
                osc.sendMsg("/hid", [ 'button', e.joy, e.button, 1 ],  ip, port) # JOYBUTTONDOWN
            elif e.type == JOYBUTTONUP: # 11
                osc.sendMsg("/hid", [ 'button', e.joy, e.button, 0 ],  ip, port) # JOYBUTTONUP
                
##            elif e.type == MOUSEBUTTONDOWN: # 11
##                osc.sendMsg("/hid", [ 'mousedown', e.joy, e.button, pygame.mouse.get_pos() ],  ip, port) # MOUSEBUTTONDOWN
##             elif e.type == MOUSEBUTTONUP: # 11
##                osc.sendMsg("/hid", [ 'mouseup', e.joy, e.button, pygame.mouse.get_pos() ],  ip, port) # MOUSEBUTTONUP
##            elif e.type == MOUSEMOTION: # 11
##                if pygame.mouse.get_pressed() :
##                    osc.sendMsg("/hid", [ 'mousedragged', e.joy, e.button, pygame.mouse.get_pos() ],  ip, port) # MOUSEMOTION
##                else : 
##                    osc.sendMsg("/hid", [ 'mousemoved', e.joy, e.button, pygame.mouse.get_pos() ],  ip, port) # MOUSEMOTION
                
            # to quit the server #
            elif e.type == QUIT : # escape key or CTRL+Q pressed
                go = 0

            if verbose : print e
            
    # quitting
    pygame.joystick.quit()
    pygame.quit()
    osc.sendMsg("/hid", [ 'quit' ],  ip, port) #QUIT
    print "HID server : quitting"
        



def run_as_app() :
    """ returns True when running as Windows exe/OSX app, and False when running from a script. -> boolean
    """
    import imp, sys
    return (hasattr(sys, "frozen") or # new py2exe
        hasattr(sys, "importers") # old py2exe
            or imp.is_frozen("__main__")) # tools/freeze



if __name__ == '__main__' :
    
    if run_as_app() :
        # mac inserts a second argument we are not interested on
        if sys.platform == 'darwin' : sys.argv.pop()
        
        print 'bundled', len(sys.argv), sys.argv

        if len(sys.argv) <= 1 : # no argvs passed
            main()
        elif len(sys.argv) == 2 :
            main(sys.argv[1])
        elif len(sys.argv) == 3 :
            main(sys.argv[1], sys.argv[2])
        elif len(sys.argv) == 4 :
            main(sys.argv[1], sys.argv[2], sys.argv[3])
        elif len(sys.argv) == 5 :
            main(sys.argv[1], sys.argv[3], sys.argv[4], sys.argv[4])
    else :
        print 'as script', len(sys.argv), sys.argv
        if len(sys.argv) <= 1 : # no argvs passed
            main()
        elif len(sys.argv) == 2 :
            main(sys.argv[1])
        elif len(sys.argv) == 3 :
            main(sys.argv[1], sys.argv[2])
        elif len(sys.argv) == 4 :
            main(sys.argv[1], sys.argv[2], sys.argv[3])
        elif len(sys.argv) == 5 :
            main(sys.argv[1], sys.argv[3], sys.argv[4], sys.argv[4])
