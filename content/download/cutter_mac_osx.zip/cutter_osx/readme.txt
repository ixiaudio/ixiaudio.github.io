Cutter
Version alpha 0.1 | info@ixi-software.net | www.ixi-software.net
Dic 04

Cutter is a very simple app. It just cuts the sound you import following the given parameters. 
The parameters you can set are : 
Slice lenght: minimun, maximun, random maximun, 
Pitch: max, min, random in between given range, microtones on/off.
Process number : Number of process of sound to run, It creates a layer of sound for each process
Volume : this is a general volume

And finally there is the option to choose between Slice Num and Timer. If you choose Slice Number it will slice the sound the number of times you set in nearby box. On the other hand if you choose Timer it will keep slicing the sound until the time you set in the box is out.

Set the parameters and press Go! button to start the process

if you find this app useful please let us know, we are always happy to get feedback from users and hear what you do and in which way you use our apps!

------------------------------------------
:: Bug report ::
Please report bugs to info@ixi-software.net
thanks!
------------------------------------------
This application has been developed in collaboration with the musician Xabier Erkizia, www.ertza.net. Ezkerrik asko Xabi.
