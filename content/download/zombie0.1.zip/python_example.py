#!/usr/bin/env python
"""
www.ixi-software.net | info@ixi-software.net
version 0.1 january 2007

check readme.txt file for how to use and documentation
"""

from zombie import *


class MyGUI(Server):
    
    def doWidgets(self):
        Label("This is just a label",  (10, 100))
        Toggle("/toggle1", 'toggle test', (200, 50), (80, 30))
        Button("/button1", 'button test', (100, 20), (90, 40))
        Slider("/slider1", 'slider test', (100, 220), (160, 40), range=(10, 1000))
        Slider("/slider2", 'slider vertical', (20, 140), (80, 100), style='vertical')
        Choice("/choice1", 'choice test', (150, 120), choices=['one.wav', 'file.wav', 'xx.wav'])
        RadioBox("/radio1", 'radiobox test', (300, 20), choices=["a", "b"])
        Number("/number1", 'number test', (300, 140), range=(3, 155), value=12)


# start up
if __name__ == '__main__':

    MyGUI(
          name='pyton test1', # name for the application
          pos=(100, 100), # position in screen
          size=(400, 350), # window size in px
          fps=10, # frames per second for the receiver loop
          ip='127.0.0.1', 
          outPort=9001,
          inPort=9000,
          app='chuck', # application to trigger
          patch='oscapp.ck' # file to trigger with app
          )
    

