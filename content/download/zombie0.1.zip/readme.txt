Zombie GUI server. version 0.1 january 2007
www.ixi-software.net | info@ixi-software.net
license LGPL


# description:
Zombie is python cross platform GUIs system that uses some wxPython widgets to create basic GUIS that send OpenSounControl data. The system has been designed with simplicity in mind. It has been designed to control sound engines programmed in languages such as ChucK or SuperCollider.

It can also be controlled from OSC capable languages (Supercollider, ChucK ...), and it receives info via OSC about how to construct the GUI. This allows to totally control it from for example ChucK (This is whay it is called Zombie). Check the ChucK examples provided.


# dependencies :
python - www.python.org
wxpython - www.wxpython.org
simpleosc - www.ixi-software.net/content/body_backyard_python.html 


Note on OSC communication
firewalls:  OSC uses network sockets so if you have a firewall in your computer your might need to grant permissions to the server and the client or open the ports used by the server. If the server takes few seconds to open up and after this is void, it is then very likely that the communication is being blocked.
Ports and IP:
The server receives by default via port 9000 and sends to localhost on port 9001. You can easily change it on the python example. For the Chuck you would need to change the ports on ChucK and also on the server source code, in the near future this will be a parameter passed to the server on start up, so it will be easier to customise the ports and ip.



# how to use 
There are two ways to use the server. The easiest is to use python to define the GUI and a OSC capable language to deal with the OSC messages sent from the widgets. Check python_example.py and oscapp.ck for an example of this method.

The second way is to control the server from the OSC capable language (we use ChucK here) to both define the GUI and to receive the OSC messages from the widgets. This method is more complex because we need to tell the server via OSC what kind of widgets we want at the right moment.  The advantages of this method are that we just deal with one programming language, the disadvantages that we need to create a way to send the right set of OSC messages to describe the GUI. 
Check the chuck_basic.ck and chuck_allwidgets.ck examples. Note that the first half of the code in the files is just a system to make simple commands in ChucK to create the widgets and deal with the  incoming OSC messages from the widgets.


=> FROM CHUCK (ZOMBIE MODE):
In this case we need to run the zombie server and then from our chosen language (at the specific times assigned by the server) tell the server how we want the widgets. To test the examples launch first the server and then the examples.

To make it simple you just need to customise the code in the examples provided by editing the following areas. 

- Describe the server window in the setWindowProps() function
args : // name, xloc, yloc, width, height, fps
example : server.setGUIProps("testing all widgets", 100, 100, 450, 350, 10);


- Describe the widgets you want to use in doWidgets() function. Here is a list of available widgets and arguments they receive in ChucK.
// label 
args :  label, x, y, width, height, rangemin, rangemax, style
example : server.doLabel("some text", 50, 100, 20, 20); //NOTE that width and height are not working yet in this widget

// toggle
args :  oscaddress, label, x, y, width, height
example : server.doToggle("/toggle1", "just a toggle", 10, 10, 90, 50);

// button
args :  oscaddress, label, x, y, width, height
example : server.doButton("/button1", "just a button", 120, 10, 100, 40);

// slider
args :  oscaddress, label, x, y, width, height, rangemin, rangemax, style, initial value
example : server.doSlider("/slider1", "just a slider", 270, 10, 160, 40, 10, 400, "horizontal", 10);

// number
args :  oscaddress, label, x, y, width, height, rangemin, rangemax, initialvalue
example : server.doNumber("/number1", "just a number", 30, 200, 30, 20, -4, 122, 3);

// choice 
args :  oscaddress, label, x, y, width, height, choices
example : server.doChoice("/choice1", "just a choice menu", 270, 220, 60, 30, "['one', 'two', 'three']");

// radio box
args :  oscaddress, label, x, y, width, height, choices
example : server.doRadioBox("/radio1", "just a radio box", 270, 100, 120, 90, "['hey', 'ho', 'lets go']", 1);

- Describe the actions that will trigger each action by creating listeners for each widget's OSCaddress like this :
class MyWidgetListener extends OscListener{
    fun void action(){  
	<<<"execute this code when the widgets is used">>>:
	e.getInt(); // most widgets send integers
	e.getString(); //RadioBox and Choice send string data type
    }
}
MyWidgetListener w; // button
w.bind( "/whateveraddress, i" ); // i is for widgets sending integers, put s for RadioBox and Choice



=> FROM PYTHON (EXTENDING THE SERVER CLASS):
We need to extend the Server class from zombie.py module. It defines a method called doWidgets() where we will create the different widgets. Check python_examples.py example provided. It both runs the server and the ChucK file.

These are all parameters of the Zombie GUI Server that can be set at start up time :
    MyGUI(
          name='Test1', # name for the application
          pos=(100,100), # position in screen
          size=(500, 300), # window size in px
          fps=15, # frames per second for the receiver loop
          ip='127.0.0.1', 
          outPort=9001,
          inPort=9000,
          app='chuck', # application to trigger
          patch='oscapp.ck' # file to trigger with app
          )

Widgets API examples on Python:
# Label(label="Some text", pos=(10, 100), size=(800,600), bgcol='Yellow')
Note that Label does not have any oscAdress because it is a static widget
bgcolor to be implemented yet
NOTE : size not working yet in labels
# Toggle(oscaddress='/dsp', label="Some label", pos=(100,120), size=(100, 50))
# Button(oscaddress='/play', label="Some label", pos=(100,120), size=(100, 50))
# Slicer(oscaddress='/vol', label="volume", pos=(100,120), size=(200, 40), range=(0, 100), style='horizontal', value=50)
# Choice(oscaddress='/file', label="sound", pos=(100,120), size=(200, 40), choices = ['a.wav', 'bb.wav'] )
# RadioBox(oscaddress='/mode', label="playmode", pos=(100,120), size=(200, 40), choices = ['normal', 'backwards'] )    
# Number(oscaddress='/dist', label="distortion", pos=(100, 130), size=(30, 25), range=(50, 150), value=100)

The widgets are created passing few arguments like this:
Number("/num1", 'number test', (300, 140), value=12, range=(3, 155)) being '/num' the address for the osc message that this widget will send when it is used. The rest are just properties for the initial state of the widget like position, size, label, range, initial value ...  They vary with each widget.

These are different ways that app and patch parameters can be passed to the Server on initialisation.
  MyGUI(size=(400, 350), fps=10, 'data\\chuck.exe', 'data\\oscapp.sc') # windows
  MyGUI(size=(400, 350), fps=10, 'data\\pd\\bin\\pd.exe -nogui', 'data\\oscapp.pd' # windows
  MyGUI(size=(400, 350), fps=10, 'sc', 'data/oscapp.sc') #unix
  MyGUI(size=(400, 350), fps=10, 'python', 'oscapp.py') # unix



# creating standalone python executables
standalone executables of the python files can be created using py2app (mac) or py2exe (windows). You just need to install either  of those libraries, edit the first lines of the packager.py module provided, and run the packager.py file. The packager will take all files in a folder called "data" and put them into the standalone executable folder. This can used to put there a sound engine patch or other type of assets if you want to create standalone python applications. You could as well use your own py2exe/py2app script of course.


# to do:
chuck examples quit shreds when quitting the app
mac slider visualise value 
being able to start the sever from command line passing arguments (ip, inport, outport etc...)
implement labels on all widgets (only some at the moment). Label positioning as well?
scroll numbers with mouse like in PD/MAX
add initial value in some widget
plot waves/graphs with wx.lib.plot.py ?
drag'n'dop area
color canvas to structure (with labels bgcolor maybe?)
# file/folder import dialogue
bangs and toggle buttons to have some visual difference
explore custom widgets
menus
...

This library is here for you to use thanks to the support of the Digital Research Unit at Huddersfield University, UK.