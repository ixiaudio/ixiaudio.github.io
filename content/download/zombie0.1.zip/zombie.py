#!/usr/bin/env python
"""
by www.ixi-software.net
license : LGPL
check readme.txt file 
"""

import wx
import osc
import time
import os

## widgets ###################
class OSCWidget(object):
    """ abstract widget base class that sends via OSC its value when interacted. 
    """
    def __init__(self, oscaddress):
        self.oscaddress = oscaddress
        self.floatEventList = [ wx.EVT_RADIOBOX.evtType[0], wx.EVT_CHOICE.evtType[0]]

    def action(self, e):
        if e.GetEventType() in self.floatEventList :
            data = str(e.GetString()) #
        else :
            data = e.GetInt()
##        print data, e.GetInt(), e.GetString()
        osc.sendMsg(self.oscaddress, [data], Server.ip, Server.outPort)
        

class Label(wx.StaticText) :
    def __init__(self, label="just a label", pos=wx.DefaultPosition, size=wx.DefaultSize, bgcol='Yellow'):
        wx.StaticText.__init__(self, Server.frame, -1, label, pos, size)
##        self.SetBackgroundColour(bgcol)
##        font = wx.Font(18, wx.Swiss, wx.Normal, wx.Normal)
##        self.SetText(font)

class Toggle(wx.ToggleButton, OSCWidget):
    def __init__(self, oscaddress, label="X", pos=wx.DefaultPosition, size=wx.DefaultSize):
        wx.ToggleButton.__init__(self, Server.frame, -1, label, pos, size)
        OSCWidget.__init__(self, oscaddress)
        Server.frame.Bind(wx.EVT_TOGGLEBUTTON, self.action, self)

class Button(wx.Button, OSCWidget):
    def __init__(self, oscaddress, label="O", pos=wx.DefaultPosition, size=wx.DefaultSize):
        wx.Button.__init__(self, Server.frame, -1, label, pos, size)
        OSCWidget.__init__(self, oscaddress)
        Server.frame.Bind(wx.EVT_BUTTON, self.action, self)

class Slider(wx.Slider, OSCWidget):
    def __init__(self, oscaddress, label="", pos=wx.DefaultPosition, size=wx.DefaultSize,
                 range=(0, 127), style='horizontal', value=0):
        if style == 'vertical' or style == 'v':
            if size == wx.DefaultSize : size = (-1, 127)
            if os.name != 'nt' :
                if os.uname()[0] == 'Darwin': 
                    style = wx.SL_VERTICAL
                else:
                    style = wx.SL_VERTICAL | wx.SL_LABELS
            else:
                style = wx.SL_VERTICAL | wx.SL_LABELS
        else:
            if size == wx.DefaultSize : size = (127, -1)
            if os.name != 'nt' :
                if os.uname()[0] == 'Darwin': 
                    style = wx.SL_HORIZONTAL
                else:
                    style = wx.SL_HORIZONTAL | wx.SL_LABELS
            else:
                style = wx.SL_HORIZONTAL | wx.SL_LABELS
                
        wx.Slider.__init__(self, Server.frame, -1, value=value, minValue=range[0],
                           maxValue=range[1], pos=pos, size=size, style=style)
        OSCWidget.__init__(self, oscaddress)
        Server.frame.Bind(wx.EVT_SCROLL_CHANGED, self.action, self) # windows only
        Server.frame.Bind(wx.EVT_SCROLL, self.action, self)

class Choice(wx.Choice, OSCWidget):
    def __init__(self, oscaddress, label="", pos=wx.DefaultPosition, size=wx.DefaultSize,
                 choices = ['zero', 'one', 'two'] ):
        wx.Choice.__init__(self, Server.frame, -1, pos=pos, size=size, choices = choices)
        OSCWidget.__init__(self, oscaddress)
        Server.frame.Bind(wx.EVT_CHOICE, self.action, self)


class RadioBox(wx.RadioBox, OSCWidget):
    def __init__(self, oscaddress, label="", pos=wx.DefaultPosition, size=wx.DefaultSize,
                 choices = ['zero', 'one', 'two'] , selected=0):
        wx.RadioBox.__init__(self, Server.frame, -1, label, pos=pos, size=size, choices = choices ,
                             majorDimension = 1, style=wx.RA_SPECIFY_COLS )
        OSCWidget.__init__(self, oscaddress)
        Server.frame.Bind(wx.EVT_RADIOBOX, self.action, self)
        self.SetSelection(selected) # which one is selected by default

class Number(wx.TextCtrl, OSCWidget):
    def __init__(self, oscaddress, label="", pos=wx.DefaultPosition, size=(30, 25),
                 range=(0, 127), value=0 ):
        wx.TextCtrl.__init__(self, Server.frame, -1, str(value), pos=pos, size=size)
        OSCWidget.__init__(self, oscaddress)

        spos = ( pos[0] + self.GetSize()[0],  pos[1] )
        ssize = ( 15, self.GetSize()[1] )
        spin = wx.SpinButton(Server.frame, -1,  spos, ssize, wx.SP_VERTICAL)
        spin.SetRange(range[0], range[1])
        spin.SetValue(value)

        Server.frame.Bind(wx.EVT_SPIN, self.action, spin)
        
    def action(self, e) : # extends superclass action
        OSCWidget.action(self, e)
        self.SetValue(str(e.GetPosition()))


## OSC zombi ################################
""" this set of osc responders interface to the widgets. So when a osc message with a
arrives it creates a widget with the values in the osc message
All widget creation must happen before the frame is shown. This is just after the
osc.sendMsg('/widgets', [1], port=Server.outPort)
message is sent.
"""
def wLabel(*msg) :
    Label( label=msg[0][2], pos=(msg[0][3], msg[0][4])) #,
           # size=(msg[0][5], msg[0][6]) )
            # NOTE : size not working yet
def wToggle(*msg) :
    Toggle(oscaddress=msg[0][2], label=msg[0][3], pos=(msg[0][4], msg[0][5]),
           size=(msg[0][6], msg[0][7]) )

def wButton(*msg) :
    Button(oscaddress=msg[0][2], label=msg[0][3], pos=(msg[0][4], msg[0][5]),
           size=(msg[0][6], msg[0][7]) )
    
def wSlider(*msg) :
    Slider(oscaddress=msg[0][2], label=msg[0][3], pos=(msg[0][4], msg[0][5]),
           size=(msg[0][6], msg[0][7]), range=(msg[0][8], msg[0][9]),
           style= msg[0][10], value=msg[0][11])

def wChoice(*msg) :
    Choice(oscaddress=msg[0][2], label=msg[0][3], pos=(msg[0][4], msg[0][5]),
           size=(msg[0][6], msg[0][7]), choices=eval(msg[0][8]) )

def wRadioBox(*msg) :
    RadioBox(oscaddress=msg[0][2], label=msg[0][3], pos=(msg[0][4], msg[0][5]),
           size=(msg[0][6], msg[0][7]), choices=eval(msg[0][8]) )

def wNumber(*msg) :
    Number(oscaddress=msg[0][2], label=msg[0][3], pos=(msg[0][4], msg[0][5]),
           size=(msg[0][6], msg[0][7]), range=(msg[0][8], msg[0][9]), value=msg[0][10] )


def bindWidgetResponders():
    osc.bind(wLabel, "/label")
    osc.bind(wToggle, "/toggle")
    osc.bind(wButton, "/button")
    osc.bind(wSlider, "/slider")
    osc.bind(wChoice, "/choice")
    osc.bind(wRadioBox, "/radiobox")
    osc.bind(wNumber, "/number")
#############################################


#############################################    

class FpsTimer(wx.Timer):
    def __init__(self, fps, f):
        wx.Timer.__init__(self)
        self.Start(1000./fps)
        self.f = f # function to call on notify

    def Notify(self): self.f()



class Server(wx.App):
    """ opens a wx pannel, inits OSC and waits for welcome message from client.
    doFrame defines the widgets in the panel. They can be created via OSC zombi commands in this module
    """
    outPort = 0
    inPort = 0
    ip = 0
    frame = 0

    def __init__(self, name='server', pos=wx.DefaultPosition, size=wx.DefaultSize, fps=15,
                 ip='127.0.0.1', outPort=9001, inPort=9000, app='', patch=''):
##    def __init__(self, *arg):
        wx.App.__init__(self, 0)

        if app != '' and patch != '' : # open patch with app as subprocess
            cmd = app+' '+patch
            pid = wx.Execute(cmd, wx.EXEC_ASYNC) #, self.process)

        # these can be changed via osc
        self.fps = fps
        self.size = size 
        self.name = name
        self.pos = pos

        # OSC
        self.connected = 0
        Server.ip = ip
        Server.outPort = outPort
        Server.inPort = inPort
        osc.init()
        self.oscIn = osc.createListener(port=inPort) # in this case just using one socket
        osc.bind(self.status, "/status") #
        osc.bind(self.setProps, "/frame")
        bindWidgetResponders() # all zombi commands
        
        # wait for a sucessful connected message from sound server
        print 'waiting for welcome mesage from sound server'
        timeout = time.time() + 10
        while not self.connected : # wait 10 secs for welcome message
            time.sleep(0.1)
            osc.getOSC(self.oscIn)
            if time.time() > timeout : break
            
        if self.connected:
            osc.sendMsg('/status', [1], port=Server.outPort) # all ready, send notification
            
        # this only happens on zombi mode when controlled via OSC
        osc.sendMsg('/frame', [1], port=Server.outPort) # tell client it is time to define widgets
        self.openingframe = 1
        timeout = time.time() + 3
        while self.openingframe: # make sure all the message arrives
            time.sleep(0.1)
            osc.getOSC(self.oscIn)
            if time.time() > timeout : break
            
        # contructing the frame
        Server.frame = wx.Frame(None, -1, self.name, self.pos, self.size)
        Server.frame.CreateStatusBar(1,0)

        osc.sendMsg('/widgets', [1], port=Server.outPort)# tell client it is time to define widgets

        self.doWidgets() # users place their code here. define the widgets
        self.t = FpsTimer(self.fps, self.step) # timer for the incomming osc loop

        if self.connected :
            s = "OSC status : ok. Receiving %i . Sending %s, %i" % (Server.inPort, Server.ip, Server.outPort)
        else:
            s = 'I did not get a welcome message from sound server'
        Server.frame.SetStatusText(s)
        Server.frame.Show(True)
        self.SetTopWindow(Server.frame)
        
        print 'wxwidgets server up and running'
        self.MainLoop() # main loop
        
        osc.sendMsg('/status', [0], port=Server.outPort) # app has exited the main loop, quiting

    def doWidgets(self) : pass
    
    def step(self):
        osc.getOSC(self.oscIn) # check for incoming msgs

    # incoming osc responders
    def status(self, *msg):
        self.connected = msg[0][0]
        print '%1 status message arrived from sound client' % self.connected

    def setProps(self, *msg):
        print 'frame props received from client'
        self.name = msg[0][2]
        self.pos = msg[0][3], msg[0][4]
        self.size = msg[0][5], msg[0][6]
        self.fps = msg[0][7]
        self.openingframe = 0 # done



if __name__ == '__main__':
    Server()

##    import sys
##    print sys.argv
##    if len(sys.argv) <= 2 :
##	main()
##    elif len(sys.argv) == 3 :
##	main(sys.argv[2])
##    elif len(sys.argv) == 4 :
##	main(sys.argv[2], sys.argv[3])
##    elif len(sys.argv) == 5 :
##	main(sys.argv[2], sys.argv[3], sys.argv[4])
##    elif len(sys.argv) == 6 :
##	main(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
