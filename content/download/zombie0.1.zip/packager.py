#!/usr/bin/env python

# edit this variables
##########################################################
main_file_name = 'zombie.py' # main file
packages = [] # any packages you might have created
icon_path = ''#'ixi_transp.ico' # on mac the icon file type is .icns on win is .ico
extra_files = [] #
# mode "console" opens an output terminal, "windows" doesnt show the terminal
mode = "windows" # "console" 
############################################################################




import os, sys, shutil
from distutils.core import setup


if os.name == 'nt' : # windows
    try :
        import py2exe
    except ImportError:
        print 'no py2app installed in your system'
elif os.uname()[0] == 'Darwin': # OSX
    try :
        import py2app as ppp
    except ImportError:
        print 'no py2app installed in your system'




def pack(mainFile='', extraPackages=[], extraFiles=[], iconPath=''):
    """ to run this module from within python
    """
    if os.name != 'nt':
        if os.uname()[0]=='Linux':
            print 'no need to pack on Linux'
            return # OFF
##        elif os.uname()[0] == 'Darwin' :
##            d = os.path.dirname(main_file_name)
##            print d
##            os.chdir(d) # change to current file directory on mac
            
    packit() # do it now!



def recursive_copy(src='', dst='', foldBlackList=(),extBlackList=()):
    """ copies tree excluding blacklisted extension files and folders
    """
    if os.path.isdir(dst) :
        shutil.rmtree(dst) # just try get rid of the old version
    for root, dirs, files in os.walk(src):
        if not len([ i for i in root.split(os.sep) if i in foldBlackList ]):
            rel = root.replace(src, '', 1) # get the relative path from dst folder downwards
            if not os.path.isdir(dst + os.sep + rel): # only if not there already
                os.mkdir(dst + os.sep + rel)
            for i in files:
                if not len([ i for j in extBlackList if i.endswith(j) ]):
                    shutil.copyfile(root + os.sep + i, dst + os.sep + rel + os.sep + i)



def proofcheck(dic):
##    print dic
    # now check for errors in user files
    if os.name == 'nt' : # windows
        f = dic[0]['script'] #  main_file_name
    else:
        f = main_file_name
        
    if not os.path.isfile(f) : 
        print 'error : %s does not seem to exist'%f
        raise sys.exit()

    if os.name == 'nt' : # windows
        i = dic[0]['icon_resources'][0][1] # icon_path
##    else:
##        i = dic[0]['iconfile'][0][1] # icon_path
        
        if len(i) == 0 or not os.path.isfile(i) :
                print 'error : icon %s does not seem to exist'%i
                if os.name == 'nt':
                    dic[0].pop('icon_resources') # this is why we do this after declaring windows
                else :
                    dic['py2app'].pop('iconfile')
    print ".. done checking user's files .........."
    print dic
    return dic




def packit():
    global main_file_name, packages, icon_path, extra_files

    print '** exporting process started **'

    # If run without args (doubleclick on win), build executable in quiet mode.
    if len(sys.argv) == 1:
        if os.name == 'nt' : # WIN
            sys.argv.append("py2exe")
##            sys.argv.append("--excludes=OpenGL") # avoid error from opengl on win
        elif os.uname()[0] == 'Darwin': # MAC
            sys.argv.append("py2app")

        sys.argv.append("-q") # for both plats

    # in case they havent been declared #
    try :
        main_file_name
    except NameError :
        print 'you did not specifly any main file in first argument for export.pack()'
        raise sys.exit() # off

    try :
        packages
    except NameError :
        packages = [] # any packages you might have created

    try :
        icon_path
    except NameError :
        icon_path = ''

    try :
        extra_files
    except NameError :
        extra_files = []

    ###################################

    # get all files and folders in subfolder 'data' and put it on the data list.
    for c, d, f in os.walk('data'):
        rel = c.replace(os.getcwd(), '', 1) # get the relative path
        if not '.svn' in rel : # in case there are hidden svn folders
            for n in range(len(f)):
                f[n] = os.path.join(rel, f[n]) # make up new tupple ('data', ['fe.wav','as.pd'])
            extra_files.append((rel, f)) #

    # checking validity for all files in extra_files
    for sub in extra_files :
        if len(sub[1]) > 0 : # files specified
            for res in sub[1]:
                if not os.path.isfile(res) :
                    i = extra_files.index(sub)
                    z = extra_files[i][1].index(res)
                    extra_files[i][1].pop(z) # remove invalid file addresses
                    print 'invalid path %s especified, ignoring'%res
        else :
            extra_files.pop(sub) # remove empty dirs
            print 'empty directory %s especified, ignoring'%res

    # make sure osc is included
    if not 'osc' in packages : packages.append('osc')
    
    ## WINDOWS ###################
    if os.name == 'nt' :
        # details for windows exe
        windows = [ dict(
            script = main_file_name,
            packages = packages,
            icon_resources = [(1, icon_path)], # id_num, file
            )
        ]

        windows = proofcheck(windows)

        # main options
        options =  dict( py2exe = dict(
            compressed = 1,
            optimize = 2,
            )
        )
        # running setup
        if mode == "windows":
            setup(
                options = options,
                windows = windows,
                zipfile =  r"lib\shardlib.zip", # This dir contains everything except the executables and the python dll.
                data_files = extra_files # resources -> str folder name , list str relative_path_to_files
            )
        else :
            setup(
                options = options,
                console = windows,
                zipfile =  r"lib\shardlib.zip", # This dir contains everything except the executables and the python dll.
                data_files = extra_files # resources -> str folder name , list str relative_path_to_files
            )

    ### MAC ######################
    elif os.uname()[0] == 'Darwin' :
        print 'deleting previous dist ...'
        try:
            shutil.rmtree(os.path.join(os.getcwd(), 'dist'))
        except:
            pass
    ##  files.append(('../Frameworks', ['/usr/local/lib/libwx_mac-2.4.0.rsrc'])) # for wx

        options = dict( py2app = dict(
            packages = packages,
        ##          # This is a shortcut that will place MyApplication.icns
        ##          # in the Contents/Resources folder of the application bundle,
        ##          # and make sure the CFBundleIcon plist key is set appropriately.
            iconfile = icon_path,
            resources = extra_files
        ))

        options = proofcheck(options)

        # running setup
        setup(
            # details for app
            app = [ main_file_name ],
            options = options
        ) # end setup



    # FOR both mac and win now :

    # now delete build dir for all platforms
    print 'deleting build dir'
    shutil.rmtree(os.path.join(os.getcwd(), 'build')) # just get rid of the old version

    print '\n'; print 'Looks like everyting went right so you should have your app in the dist folder'#%os.path.basename(main_file_name)





if __name__ == '__main__' : pack()







