
Open Sound World Server for SpinOSC


This patch demonstrates the use of Open Sound World (OSW) as a target for SpinOSC.
It respons to OpenSound Control (OSC) messages from SpinOSC and uses the
OSW namespace to automatically route messages from SpinOSC objects to
correspending elements in the OSW patch.

If you do not already have OSW, more information and downloads can be found at:
http://www.opensoundworld.com

More information on SpinOSC can be found at:
http://www.ixi-software.net/content/body_software_spinosc.html

To install and run, place all the files from this package in a directory
of your choice.  Launch the patch by double-clicking spin.osw under
Mac OS X or Windows, or running "osw spin.osw" from the command line on
any platform.  Once OSW is running, launch SpinOSC.  OSW should then
respond to the spins that you create on the SpinOSC canvas.

Have fun!
