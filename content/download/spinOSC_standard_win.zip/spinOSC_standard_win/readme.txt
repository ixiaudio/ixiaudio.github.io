spinOSC | version public beta 0.1.2 | 29-March-04 | www.ixi-software.net | info@ixi-software.net



*NOTE: When SpinOSC starts up you get an empty space where you have to create spins to get sound
To create the spins --> Hold down any key from 1 to 0  + click on the stage to create a Spin.*




New features in this version --
version 0.1.2
- Included latest OSC external for PD. It can be found in the pd_osc_external folder. This version allows to send negative numbers and some other interesting features that the previous one didnt support.
- The interface stays now on top of the program launched by the .bat
- Better OSC communication.




Description 

SpinOSC is an interface to programs such as Pure Data that sends OSC messages. SpinOSC allows the useer to create rotating objects - spins - that trigger messages while thy spin. The 
number of messages they trigger depends on the number of boxes that each spin contains (1 to 10 at the moment).
The messages are in OSC format (Read more about Open Sound Control protocol on 
http://cnmat.cnmat.berkeley.edu/OSC/ ). 

The messages carry information about the properties of each spin such as: location, number of boxes, size, rotation 
speed etc... These properties can be easily controlled and changed by the user.

SpinOSC contains a patch example developed in Pure Data . You can send OSC to many other applications. It is up to you to map the values you get from the Spins to control whatever value in the receiving end.

In the standard edition sounds can be imported into each spin by droping the files on top of them.

SpinOSC contains parts that are developed and copyrighted by others:
Pure Data copyright by Miller Smith Puckette and others. http://www.pure-data.org 
OSC external for PD http://barely.a.live.fm/pd/OSC (the latest osc.dll is included in this distribution in the "pd_osc_external" folder)
Python Xtra copyright by Steve Spicklemire Silicon Prairie Ventures, Inc. (and) University of Indianapolis
Python OSC implementation developed by Daniel Holth. http://galatea.stetson.edu/~ProctoLogic/

For more details check the help.gif screenshot with description of functionality included with the main folder.


Note about versions:
The "expert version" is intended to be used by expert users that have experience using and writing patches on PD or MAX/MSP. If you are not familiar with this programs you should start using the "basic" version. The main difference is that the "windows basic" version includes and runs automaticly a distribution of PureData (www.pure-data.org) and an example patch.


-- Sytem requirements --
+1500 mhz
+256 RAM 
The current version only works on Windows and it has been tested on XP. But we have plans to create OSX and Linux 
versions.
If you have a Firewall like ZoneAlarm you will need to allow SpinOSC to act as a server, otherwise the firewall will 
block the OSC messages.



-- Install --
No need to install. Just unzip somewhere in your hardrive and run spinOSC.exe.
However since spinOSC is just an inteface that sends out OSC messages you need to have some other software listening to the messages and responding to them in whatever way you might choose, from creating sound to controlling the light in your room. spinOSC has been primarily designed to comunicate to Pure Data but you could use any other software or device that understands OSC.
If you experience problems please let us know --> info@ixi-software.net





:::: Shortcut Reference and how to use ::::

General -
CNTR + N - New File
CNTR + O - Open File
CNTR + S - Save File
CNTR + D - Save File As
CNTR+ Q - Quit 
Arrow Up - Increase volume (+ SHIFT to increase faster)
Arrow Down - Decrease volume (+ SHIFT to decrease faster)
CTRL + number (1 to 0) - Set volume up or down
CTRL + C to copy selected Spins
CTRL + V to paste copied Spins
CNTR + H - Quick help & Shortcut Reference



Selection -
Click and drag to make selections.
SHIFT + click and drag to add new selection to the previous one.
CTRL + A to select all spins (Apple + A on Mac)


Spin -
A maximun of 50 spins can be created (We thought that 50 would be enough for any situation). If you ever need more than this for some insane reason ;-) let us know and we will increase the max number of objects for you! 
Hold down any key from 1 to 0  + click on the stage to create a Spin.
Keys 1 to 0 to change the number of sounds of selected Spins.
Click + drag to move Spins.
Arrow keys - to move selected Spins. (+ SHIFT to move faster)
"+" to increase size of selected Spins. (+ SHIFT to change faster)
"-" to decrease size of selected Spins. (+ SHIFT to change faster)
"E" to hold the rotation of selected Spins.
"Q" to reset rotation of selected Spins to original position.
"Z" to activate/ deactivate selected Spins.
"A" to set selected Spins bigger
"S" to set selected Spins smaller
Hold down "R" an drag to record a movement
CTRL + X to stop movement of selected Spins


OSC communication - (Open Sound Control)
Read more about OSC protocol on http://cnmat.cnmat.berkeley.edu/OSC/
CTRL + R to reinitialise OSC communication
CTRL + T to send a TRUE (1) message
CTRL + F to send a FALSE (0) message
The communication port is set by default to 9000. It can be changed by typing the new port number on the top right 
corner text field. Check the content of the Prefs file for more information about whats possible.


Drag and Dop -
If you drag and drop a file on a Spin there is a message sent from that spin (and all selected Spins) like:
"/spin/IDnumber/drop path_to_the_file"
If you drag a file on to an empty area of the application there is a message like this being sent:
"/drop path_to_the_file"
This is used to attach sounds to the Spins in the spinOSC standard version (only for .wav sounds).  There is no any file type checking at all. You can use drag and drop functionality for any porpose you might think of.


OSC Messages sent by spinOSC --
Initial Volume and number of Spins are sent when the OSC communication is initalised
When the app starts it sends out "/boolean 1" message
When the app quits it sends out "/boolean 0" message
"New" sends out "/new 1" message 
"Open" sends out "/open 1" message 
"Save" sends out "/save 1" message 
"Save as" sends out "/saveas 1" message 
"Quit " sends out "/quit 1" message
Changing the volume sends out a message like "/vol 100" with the new volume value.

Every Spin sends out a message when each of the boxes of the spin gets to the highest position.
A 5 boxes spin would send 5 messages every round, one for each box.
This is the format of the message : "/spin/IDnumber/data horizontalLoc verticalLoc rotation width "
Creating a spin sends out a message like "/spin/IDnumber/born bang"
Killing a spin sends out a message like "/spin/IDnumber/dead bang"
The IDnumber can be edited manually by the user. Any number from 0 to 999 can be used, but you have to make sure that you are listening to it in PD!


Note about MIDI -
spinOSC doesnt send MIDI at the moment. But you could easily translate the incomming OSC data into MIDI messages in the receiving end (PD, SuperCollider, etc...) and send it again to control some external device or some program that only understands MIDI.


Preferences file -
The file called Prefs.txt inside the Preferences folder can be customised allowing to choose size and location of the 
SpinOSC window, background color, Spins' blinking color, default volume, default OSC communication port, IP and 
also choose a file that spinOSC runs when the apps is initialised. This lasts feature allows you, for example, to create .bat files that run PD opening the patch you want to use and loads the externals needed. 
WARNING!: do NOT change the format of the text in the Prefs, only change the values. Make sure you dont insert ANY extra line breaks!!


Notice :
Please note that using the menus (save, save as, open, new ...) halt temporarily the application while they are open. If you are in the middle of a performance you might want to use the shortcuts provided instead of the menus.



For comments, report bugs or any kind of feedback --> info@ixi-software.net


Have fun !


Changelog:

beta 0.11:
- Added Drag and Drop functionality
- Changed OSC Python implementation to ProctoLogic
- Now the IP to connect can be set on the Prefs file. (Before it was hardwired to 'localhost')

