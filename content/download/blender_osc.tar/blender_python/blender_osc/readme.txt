blender to PureData OpenSoundControl comunication example

july 06

by www.ixi-software.net

License : LGPL

URL : http://www.ixi-software.net/content/body_backyard_blender.html

Description:
This example shows how to use simpleOSC library from ixi-software.net to send and receive OSC 
from/to blender with a very simple to use API by hidding the complex stuff. Latest osc library by 
ixi-software can be downloaded from 
http://www.ixi-software.net/content/body_backyard_osc.html

SimpleOSC uses OSC.py module by Daniel Holth

How to use:
Check python scripts in the blender example file for detailed use description.
The osc folder must be somewhere in your pythonpath. The simplest solution is to keep it next to
the .blend file that imports it.

Files:
simpleOSC.blender -> Blender file sending and receiving OSC
simpleOSC.pd -> pure data patch sending and receiving OSC
osc folder -> contains python modules that manage the OSC

enjoy
