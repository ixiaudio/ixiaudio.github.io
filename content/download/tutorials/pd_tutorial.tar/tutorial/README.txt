ixi pd tutorial : 

some examples explaining the very basics of Pure Data

Note that pd_player and pd_sampler are unfinished patches that are just there so that you get an idea how it feels.

Drum-machine by nullpointer.co.uk copyright by nullpointer

the rest is under this license
---------------------------------------------------------------
  Copyright (c) 2006, ixi software.
  This work is licensed under a Creative Commons  
Attribution-NonCommercial-ShareAlike 2.0 England & Wales License.
  http://creativecommons.org/licenses/by-nc-sa/2.0/uk/
--------------------------------------------------------------- 