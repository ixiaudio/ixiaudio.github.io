this Pd patch is by tom betts aka Nullpointer.
please check his work out, very interesting
www.nullpointer.co.uk

the latest version of the patch and some other stuff in pd by him can be found here
http://www.nullpointer.co.uk/-/pd.htm