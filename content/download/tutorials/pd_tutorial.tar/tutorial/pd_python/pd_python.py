""" this is just a reworked example from the py/pyext external's documentation
grrrr.org/py
"""

# some basic functions

def f1():
    print 'f1'

def f2(n):
    print n

def f3(a,b):
    return a+b



# So here we go into OOP :

#################################################################
# we MUST import pyext as we need to extend pyext._class
try:
    import pyext
except:
    print "ERROR: This script must be loaded by the PD/Max pyext external"

#################################################################

class Basic(pyext._class):
    """simple class"""
    # number of inlets and outlets as a class variable inherited from pyext._class
    _inlets = 2
    _outlets = 2

    def __init__(self):
        print "-> init Basic class"

    # methods for first inlet
    def bang_1(self):
        print "Bang into first inlet"

    def int_1(self,f):
        print "Integer",f,"into first inlet"

    def float_1(self,f):
        print "Float",f,"into first inlet"

    def list_1(self,*s):
        print "List",s,"into first inlet"


    # methods for second inlet
    def hey_2(self):
        print "Tag 'hey' into second inlet"

    def ho_2(self):
        print "Tag 'ho' into second inlet"


################
class Counter(pyext._class):
    """counter that can be reseted"""
    # number of inlets and outlets as a class variable inherited from pyext._class
    _inlets = 2
    _outlets = 2

    def __init__(self):
        print "-> init Counter class"
        self.count = 0
        self.delta = 1 # increase rate
#	self._outlet(2, self.delta) # WARNING : do not use the outlet at this point or you will get an error in the class

    def bang_1(self):
        self.count += self.delta
        self._outlet(1, self.count)

    def int_2(self, n):
        self.delta = n
        self._outlet(2, self.delta)

    def reset_1(self):
        self.count = 0
        self.delta = 1
        self._outlet(2, self.delta)
        self._outlet(1, self.count)

