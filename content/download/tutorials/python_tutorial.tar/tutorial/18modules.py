import mymodule # this is my custom module!!

import time # python built in module


def Main():
    c = mymodule.Counter() # instanciate class from custom module

    while 1:
        c.add(10) # increase by 1
        print c.getCount() #p rint count
        print mymodule.randomRGB() # function from custom module
        time.sleep(0.1)


if __name__ == '__main__': Main()


