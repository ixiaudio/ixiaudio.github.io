#diccionaries
dic = {"name": "enrike", "surname":"Hurtado Mendieta", "age": 31}
print dic["name"]
print dic["surname"]
print dic["age"]

dic["hair"] = "brown" #adding new one

print dic



#tuples
x = (2, 3, 4)
z = "a", "b", "c"

print x[0], z[1]
print x[2], z[2]

x[2] = 22 # this produces and error, as you will see in the output console



