import random

r = random.Random() # must init random seed

q = r.randint(0, 5)
h = r.randint(0, 5)

if q < h:
    print "q is smaller than h"
elif q == h:
    print "q is equal to h"
else:
    print "q is bigger than h"

