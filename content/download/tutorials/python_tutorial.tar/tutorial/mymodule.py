
# this is just a module with some useful function and classes to be used from
# some other python files
import random

# the global seed to be used down in the randomRGB() function
r = random.Random() # must init random seed


def randomRGB():
    rgb = r.randint(0, 255), r.randint(0, 255), r.randint(0, 255)
    return rgb
    # or:
    #a = r.randomInt(0, 255)
    #b = r.randomInt(0, 255)
    #c = r.randomInt(0, 255)
    #return a,b,c



class Counter:
    """ a simpler counter
    """
    def __init__(self):
        # inits the count prperty
        self.count = 0

    def add(self, delta):
        # adds a num to the count property
        self.count += delta

    def getCount(self):
        # returns the value of the count prop
        return self.count


