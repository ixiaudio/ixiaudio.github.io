import time # i am gonna use Python time module so i need to import it


print "hi again"

x = 0
print x

astring= "some blah blah"
print astring

while True: # neverending loop
    x += 1
    print "neverending ... " + str(x)

    time.sleep(0.5) # you don't need this, but otherwise it goes as fast as it can go



