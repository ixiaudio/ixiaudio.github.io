
print "hi people!"

x = 333
z = 666

print x, z

print (x+z)/2.1

print "x plus z is " + str(x+z)

print "good bye now, this is the last line!"

