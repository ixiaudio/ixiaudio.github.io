


def main():
    print "starting"

    while True: # or while 1:
        print "loooping"


if __name__ == '__main__':
    main() # or whatever other name you like


