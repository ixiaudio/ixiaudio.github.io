class Counter:
    """ a simpler counter
    """
    def __init__(self):
        # inits the count prperty
        self.count = 0

    def add(self, delta):
        # adds a num to the count property
        self.count += delta

    def getCount(self):
        # returns the value of the count prop
        return self.count




def Main():
    c = Counter()
    d = Counter() # another counter

    c.add(5)
    print c.getCount()

    d.add(1000)
    print d.getCount()

    c.add(15)
    print c.getCount()

    d.add(999)
    print d.getCount()





if __name__ == '__main__': Main()



