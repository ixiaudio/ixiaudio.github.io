a = 67245

def testvariables():
    a = 999
    print a # this is a local variable

def Main():
    testvariables()
    print a # but this is global because it was declared outside any def

if __name__ == '__main__': Main() # or whatever other name you like

