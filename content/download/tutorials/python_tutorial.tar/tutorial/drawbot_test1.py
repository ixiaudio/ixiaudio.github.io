import random # need to import the module to use later to get rand numns, this is normal python module

def init():
    """ drawbot built in init function
    """
    global seed # declare as global as it must be accesible later from the loop func
    seed = random.Random() # must init the seed


def drawOval():
    """this is our  custom made function to draw ramdon ovals
    """
    global seed # remember to declare globals always within functions, it will save you few hedaches
    r, g, b, a = seed.random(), seed.random(), seed.random(), seed.random()
    fill(r,g,b,a)

    x = seed.randint(0, 200) # horizontal
    y = seed.randint(0, 400) # vertical
    w = seed.randint(1, 200) # width
    h = seed.randint(1, 200) # height

    oval(x, y, w, h) # now draw it


def loop():
    """ drawbot built in loop function
    """
    for i in range(100): # few times every loop
        drawOval()

