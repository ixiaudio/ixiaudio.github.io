#!/usr/bin/python


from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

global rot
rot= 0


def initGL(w, h):                               # We call this right after our OpenGL window is created.
    glClearColor(0.0, 0.0, 0.0, 0.0)    # This Will Clear The Background Color To Black
    glClearDepth(1.0)                                   # Enables Clearing Of The Depth Buffer
    glDepthFunc(GL_LESS)                                # The Type Of Depth Test To Do
    glEnable(GL_DEPTH_TEST)                             # Enables Depth Testing for depth layering f objects
    glShadeModel(GL_SMOOTH)                             # Enables Smooth Color Shading

    glMatrixMode(GL_PROJECTION) # working with the projection matrix
    glLoadIdentity()                                    # Reset The Projection Matrix
    gluPerspective(45.0, float(w)/float(h), 0.1, 100.0) # set perspective, 3D in this case

    glMatrixMode(GL_MODELVIEW) # from now on working on drawing and not on the projection matrix




def draw():
    """# The main drawing function.
    """
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    glLoadIdentity()                                    # Reset The View

    # Move Right 1.5 units and into the screen 6.0 units.
    glTranslatef(1.5, 0.0, -6.0)

    # Draw a square (quadrilateral) rotated on the X axis.
    glRotatef(rot, rot, rot, 0.0)               # Rotate

    glColor3f(1, 0.5, 1.0)          # color, as rgb, each component accepts values between 0 and 1. so 1,1,1 is white, 1,0,0 is red and so on ...

    glBegin(GL_QUADS)                   # Start drawing a 4 sided polygon
    glVertex3f(-1.0, 1.0, 0.0)          # Top Left
    glVertex3f(1.0, 1.0, 0.0)           # Top Right
    glVertex3f(1.0, -1.0, 0.0)          # Bottom Right
    glVertex3f(-1.0, -1.0, 0.0)         # Bottom Left
    glEnd()                             # We are done with the polygon

    #  since this is double buffered, swap the buffers to display what just got drawn.
    glutSwapBuffers()


def idle():
    global rot
    rot+= 0.05

    glutPostRedisplay() # tell glut to redraw



def main():
    import sys
    glutInit(sys.argv)

    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH)# double buffer and depth buffer

    glutInitWindowPosition(20,20)
    glutInitWindowSize(400, 300)
    glutCreateWindow("my glut window")

    glutDisplayFunc(draw) # tell glut which funtions to call when those event are triggered
    glutIdleFunc(idle)

    # Initialize our window.
    initGL(400, 300)

    # Start Event Processing Engine
    glutMainLoop()



if __name__ == '__main__': main() # or whatever other name you like







