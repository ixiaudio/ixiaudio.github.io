
#!/usr/local/bin/python2.3

import pygame
import pygame.event
from pygame.locals import *     # this is for the key constants (K_a, K_LEFT, etc...)


try: # joystick
    pygame.joystick.init() # init main joystick device system
    for n in range(pygame.joystick.get_count()): #
        stick = pygame.joystick.Joystick(n)
        stick.init() # init instance
        # report joystick charateristics #
        print '-'*20
        print 'Enabled joystick: ' + stick.get_name()
        print 'it has the following devices :'
        print '--> buttons : '+ str(stick.get_numbuttons())
        print '--> balls : '+ str(stick.get_numballs())
        print '--> axes : '+ str(stick.get_numaxes())
        print '--> hats : '+ str(stick.get_numhats())
        print '-'*20
except pygame.error:
    print 'no joystick found.'




def main():
    """prepare everything and then go into main loop
        In preparation area init pygame, background, and objects
        In main loop update sprites and check for events
        last thing to do is to render all screen
        """
    pygame.init() # --> this area before the main while loop is like a "preparemovie" area
    #screen = pygame.display.set_mode((800, 600))

    #pygame.mouse.set_visible(1)
        ##Create the background surface
    #background = pygame.Surface(screen.get_size())
    #background = background.convert()

    #background.fill((255,255,255))             #

    #screen.blit(background, (0, 0))        # initialise the background
    #pygame.display.flip() # render it

    clock = pygame.time.Clock()             # create the clock


    ## MAIN LOOP
    while 1 :                               # main application loop
        clock.tick(20)                      # set frame rate in fps

        for e in pygame.event.get():                    # iterate over event stack
            if e.type is pygame.locals.JOYAXISMOTION: # 7
                print e.joy, e.axis, e.value

            elif e.type is pygame.locals.JOYBALLMOTION: # 8
                print e.joy, e.ball, e.value

            elif e.type is pygame.locals.JOYHATMOTION: # 9
                print e.joy, e.hat, e.value

            elif e.type is pygame.locals.JOYBUTTONDOWN: # 10
                print e.joy, e.button

            elif e.type is pygame.locals.JOYBUTTONUP: # 11
                print e.joy, e.button

        #screen.blit(background, (0, 0)) # clean the bg

        #pygame.display.update()   # update all rects in one go
        #pygame.display.flip()



if __name__ == '__main__': main()





