from wxPython.glcanvas import wxGLCanvas
from wxPython.wx import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
from OpenGL.GL import *
import sys,math

name = 'opengl_wxpython_basic'

import random
r = random.Random()

class myGLCanvas(wxGLCanvas):
    def __init__(self, parent):
        wxGLCanvas.__init__(self, parent,-1)
        EVT_PAINT(self, self.OnPaint)
        self.init = 0
        return

    def OnPaint(self,event):
        dc = wxPaintDC(self)
        self.SetCurrent()
        if not self.init:
            self.InitGL()
            self.init = 1
            #t = RefreshTimer(self, 1) # canvas to refresh and fps
            self.OnDraw()
            return

    def OnDraw(self):
        glClearColor(1,1,1,0)
        glClearDepth(1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        glPushMatrix()

        self.sq(3,(1.0, 0.0, 0.0))
        # --------------
        glTranslatef(0.5, 0.7, -0.5)
        # -------------
        self.sq(3,(0.0, 1.0, 0.0, 0.7))
        # --------------
        glTranslatef(0.5, 0.7, 1.5)
        # --------------
        self.sq(3,(0.0, 0.0, 1.0, 0.5))

        glPopMatrix()

        self.SwapBuffers()
        return

    def sq(self, w, c):

        if len(c)>3 :
            glColor4f(c[0], c[1], c[2], c[0])
            glEnable (GL_BLEND)
            glDepthMask (GL_FALSE)
            #glBlendFunc (GL_SRC_ALPHA, GL_ONE);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        else:
            glColor4f(c[0], c[1], c[2], 1)

            glBegin(GL_QUADS)
            glVertex2f(-w/2,  w/2)
            glVertex2f( w/2,  w/2)
            glVertex2f( w/2, -w/2)
            glVertex2f(-w/2, -w/2)
            glEnd()

        if len(c)>3 :
            glDepthMask(GL_TRUE)
            glDisable(GL_BLEND)



    def InitGL(self):
        # set viewing projection
        #light_diffuse = [1.0, 1.0, 1.0, 1.0]
        #light_position = [1.0, 1.0, 1.0, 0.0]

        #glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse)
        #glLightfv(GL_LIGHT0, GL_POSITION, light_position)

        #glEnable(GL_LIGHTING)
        #glEnable(GL_LIGHT0)
        glEnable(GL_DEPTH_TEST)
        glClearColor(0.0, 0.0, 0.0, 1.0)

        glDepthFunc(GL_LEQUAL)
        glEnable(GL_DEPTH_TEST)

        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        glOrtho(-5, 5, -5, 5, -5, 5)  ##    gluOrtho2D(left, right, bottom, top)
        #gluPerspective(40.0, 1.0, 1.0, 30.0)

        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        #glTranslatef(1, 0, 1)
        glPushMatrix()
        #gluLookAt(0.0, 0.0, 10.0,
        #   0.0, 0.0, 0.0,
        #   0.0, 1.0, 0.0)
        return


class RefreshTimer(wxTimer):
    """ Calls refresh at a given FPS.  args are : canvas object to refresh and FPS
    """
    def __init__(self, canvas, fps):
        wxTimer.__init__(self)
        f = 1000.0/fps # get the millisecs of freq for that rate in fps
        self.Start(f) # millisecs of frequency
        self.canvas = canvas

    def Notify(self):
        """ Refresh(self, bool eraseBackground=True, Rect rect=None)
        Mark the specified rectangle (or the whole window) as "dirty" so it will be repainted.
        Causes an EVT_PAINT event to be generated and sent to the window.
        """
        self.canvas.Refresh(True)


def main():
    app = wxPySimpleApp()
    frame = wxFrame(None,-1,'ball_wx',wxDefaultPosition,wxSize(400,400))
    canvas = myGLCanvas(frame)
    frame.Show()
    app.MainLoop()

if __name__ == '__main__': main()





