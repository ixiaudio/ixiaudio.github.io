#!/usr/local/bin/python2.3

import pygame
import pygame.event
from pygame.locals import *     # this is for the key constants (K_a, K_LEFT, etc...)

import random
r = random.Random() # always init the random seed



def main():
    """prepare everything and then go into main loop
        In preparation area init pygame, background, and objects
        In main loop update sprites and check for events
        last thing to do is to render all screen
        """

    pygame.init() # --> this area before the main while loop is like a "preparemovie" area
    screen = pygame.display.set_mode((800, 600))

    pygame.mouse.set_visible(1)
        #Create the background surface
    background = pygame.Surface(screen.get_size())
    background = background.convert()

    rgb = (r.randint(0,255), r.randint(0,255), r.randint(0,255))
    background.fill(rgb)                # fill bg with random rgb color

    screen.blit(background, (0, 0))         # initialise the background
    pygame.display.flip() # render it

    clock = pygame.time.Clock()             # create the clock


    ## MAIN LOOP
    while 1 :                               # main application loop
        clock.tick(20)                      # set frame rate in fps

        for event in pygame.event.get():    # handle events
            if event.type == QUIT:
                return # returns exits the while 1 loop and ends the program
            elif event.type == KEYDOWN and event.key == K_ESCAPE:
                return
            elif event.type == MOUSEBUTTONDOWN:
                print "mousedown"

        #rgb= (r.randint(0,255), r.randint(0,255), r.randint(0,255))
        #background.fill(rgb)
        #screen.blit(background, (0, 0))

        a, b, c, d = r.randint(0, 800), r.randint(0, 800), r.randint(0, 800), r.randint(0, 800)
        color = r.randint(0, 255), r.randint(0, 255), r.randint(0, 255) # i could put this into brackets () but itsnt necesary

        # **EXPLAIN differences between above methods of creating the tupples**
        pygame.draw.rect(background, color, (a, b, c, d), 0)
        screen.blit(background, (0, 0)) # clean the bg

        #pygame.display.update()   # update all rects in one go
        pygame.display.flip()



if __name__ == '__main__': main()





