#include "Python.h"
//#include "arrayobject.h"
//#include <math.h>

//#define IDATA(p) ((int *) (((PyArrayObject *)p)->data))
//#define DDATA(p) ((double *) (((PyArrayObject *)p)->data))





static PyObject *py_test(PyObject *self, PyObject *args){
	int *x,*y;
	if (x>y){
		return Py_BuildValue("i",x);
	}else{
		return Py_BuildValue("i",y);
	}
}

static PyObject *py_hello(PyObject *self, PyObject *args){
	return Py_BuildValue("s", "hello world");
}



static PyMethodDef utilities_methods[] = {
	{"ctest",py_test,METH_VARARGS},
	{"chello",py_hello,METH_VARARGS},
  	{NULL,NULL} /* Sentinel */
};

void initutilities(){
  (void) Py_InitModule("utilities", utilities_methods);
}

