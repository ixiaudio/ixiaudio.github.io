#include "Python.h"



static PyObject *py_constrain(PyObject *self, PyObject *args){
	int *x,*y, *l, *t, *r, *b;
	int ok;
	
	ok = PyArg_ParseTuple(args, "iiiiii",&x,&y,&l,&t,&r,&b);
  
 	if (!ok){
  	  fprintf(stderr,"Error (constrain) in parsing arguments\n");
  	  exit(1);
  	}

	if (x < l) {x = l;}
	if (x > r) {x = r;}

	if (y < t) {y = t;}
	if (y > b) {y = b;}

	return Py_BuildValue("ii",x,y) ;

}
/*
def rotPoint(point, axis, ang):
    """ Orbit. calcs the new loc for a point that rotates a given num of degrees around an axis point,
        +clockwise, -anticlockwise -> x,y
    """
    radius = distance(point, axis) # calc radius
    RAng = radians(ang-90)       # convert ang to radians. -90 to convert to normal ang system from opengl.

    lH = axis[0] + ( radius * cos(RAng) )
    lV = axis[1] + ( radius * sin(RAng) )

    return lH, lV
*/

static PyMethodDef utils_methods[] = {
	{"constrain", py_constrain, METH_VARARGS},
  	{NULL,NULL} /* Sentinel */
};


void initutils(){
  (void) Py_InitModule("utils", utils_methods);
}
