#include "Python.h"
#include "arrayobject.h"
#include <math.h>

#define IDATA(p) ((int *) (((PyArrayObject *)p)->data))
#define DDATA(p) ((double *) (((PyArrayObject *)p)->data))



static PyObject *py_test(PyObject *self, PyObject *args){
	int *x, *y;
	int ok;

	ok = PyArg_ParseTuple(args, "ii",&x,&y);
  
 	if (!ok){
  	  fprintf(stderr,"Error (print) in parsing arguments\n");
  	  exit(1);
  	}

	if (x > y){
		return Py_BuildValue("i",x);
	}else{
		return Py_BuildValue("i",y);
	}
}





static PyObject *py_hello(PyObject *self, PyObject *args){
	return Py_BuildValue("s", "hello world!!");
}





static PyObject *py_print(PyObject *self, PyObject *args){
	char *s;
	int ok;
 	ok = PyArg_ParseTuple(args, "s",&s);
  
 	if (!ok){
  	  fprintf(stderr,"Error (print) in parsing arguments\n");
  	  exit(1);
  	}
	return Py_BuildValue("s", s);
}




static PyObject *py_constrain(PyObject *self, PyObject *args){
	int *x,*y;
	PyObject *rect;
	double r;
	int ok;
	
	ok = PyArg_ParseTuple(args, "0", &rect);
  
 	if (!ok){
  	  fprintf(stderr,"Error (constrain) in parsing arguments\n");
  	  exit(1);
  	}

  	r = DDATA(rect);

	if (x < r[0]) {x = r[0];}
	if (x > r[2]) {x = r[2];}

	if (y < r[1]) {y = r[1];}
	if (y > r[3]) {y = r[3];}

	return Py_BuildValue("ii",x,y) ;

}
/*
static PyObject *py_constrain(PyObject *self, PyObject *args){
	int *x,*y, *l, *t, *r, *b;
	int ok;
	
	ok = PyArg_ParseTuple(args, "iiiiii",&x,&y,&l,&t,&r,&b);
  
 	if (!ok){
  	  fprintf(stderr,"Error (constrain) in parsing arguments\n");
  	  exit(1);
  	}

	if (x < l) {x = l;}
	if (x > r) {x = r;}

	if (y < t) {y = t;}
	if (y > b) {y = b;}

	return Py_BuildValue("ii",x,y) ;

}

*/




static PyMethodDef test_methods[] = {
	{"test", py_test, METH_VARARGS},
	{"hello", py_hello, METH_VARARGS},
	{"cprint", py_print, METH_VARARGS},
	{"constrain", py_constrain, METH_VARARGS},
  	{NULL,NULL} /* Sentinel */
};


void inittest(){
  (void) Py_InitModule("test", test_methods);
}



