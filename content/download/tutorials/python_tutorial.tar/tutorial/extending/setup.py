from distutils.core import setup, Extension

module1 = Extension('utils',
    sources = ['utils.c'])

setup (name = 'utils',
    version = '1.0',
    description = 'some utils',
    ext_modules = [module1])


