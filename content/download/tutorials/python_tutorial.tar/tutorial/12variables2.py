a = 67245

def testvariables():
    global a
    a = 999
    print a # now it has changed because i declared it as global
    # inside the def. Globals MUST be declared as globals inside defs
    # or clases when they being assigned a value

def Main():
    testvariables()
    print a # so both print same value

if __name__ == '__main__': Main() # or whatever other name you like

