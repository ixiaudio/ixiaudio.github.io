try :
    import dlfghadkfjhgsidufhgsipdufhg
except ImportError:
    print "there is no such a horrible library like that one"



while 1:
    try:
        x = int(raw_input("Please enter a number: "))
        break
    except ValueError:
        print "Oops! That was no valid number.  Try again..."

