
nums = [1, 2, 4]
for x in nums :
    print x

months = ["june", "july", "august"]
for y in months:
    print y

# < one line statement its also posible
for n in range(19): print n

# and also two lines if separated by ;
# but dont get very excited about this, its confussing
for n in range(19): print n; print n*n


# Beware !!!!!!!!!!!!!!!!!!!!
x= [1,2,3]
z=x
x[1]='a'
print z[1] # this has changed as well

# so the best is to do this
x= [1,2,3]
z=x[:] # it duplicates it
x[1]='a'
print z[1] # now it hasnt changed


