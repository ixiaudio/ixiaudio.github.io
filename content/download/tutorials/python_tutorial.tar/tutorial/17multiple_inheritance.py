import time

class Counter:
    """ a simpler counter
    """
    def __init__(self):
        # inits the count prperty
        self.count = 0

    def add(self, delta):
        # adds a num to the count property
        self.count += delta

    def getCount(self):
        # returns the value of the count prop
        return self.count

class YieldOnEven:
    def __init__(self): # no need to have this but there it goes
        pass

    def checkEvens(self, num):
        if num % 2 == 0: # if reminder of num/2 is 0 then is an even number
            print "IT WAS AN  EVEN NUMBER!"



class CounterYieldsOnEven(Counter, YieldOnEven): # inherits from Counter
    def __init__(self, max):
        Counter.__init__(self) # initalises its 1st superclass
        YieldOnEven.__init__(self) # initalises its 2nd superclass

        self.max = max # and specilises it by extending the init def

    def checkReset(self): # and by implementing bew functions
        self.checkEvens(self.count) # inherited from YieldOnEven class

        if self.count >= self.max:
            print "max reached!!!"
            self.count = 0
        else:
            print "not yet"




def Main():
    c = CounterYieldsOnEven(50) # init with max value to 100

    while 1:
        c.add(1) # increase by 1
        print c.getCount() #p rint count
        c.checkReset() # check if we reached max value
        time.sleep(0.1)





if __name__ == '__main__': Main()







