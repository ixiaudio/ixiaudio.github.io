#first import modules
import time
import random

#initalise r
r = random.Random() # must init random seed

def add(a, b):
    """ this is the way python does long comments
    here we are defining the function add
    """
    sum = a+b
    return sum



def Main():
    print "starting"

    while True: # or while 1:
        a = r.randint(0, 20)
        b = r.randint(100, 200)
        print a, b, add(a,b)

        time.sleep(0.5) # you don't need this, but otherwise it goes as fast as it can go



if __name__ == '__main__': Main() # or whatever other name you like






