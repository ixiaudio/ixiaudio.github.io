class Counter:
    """ a simpler counter
    """
    def __init__(self):
        # inits the count prperty
        self.count = 0

    def add(self, delta):
        # adds a num to the count property
        self.count += delta

    def getCount(self):
        # returns the value of the count prop
        return self.count


def Main():
    c = Counter()
    c.add(5)
    print c.getCount()
    c.add(15)
    print c.getCount()



if __name__ == '__main__': Main()


