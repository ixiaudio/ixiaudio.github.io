def add(a, b):
    sum = a+b
    return sum


print add(3,5)
print add(3000, 2)

