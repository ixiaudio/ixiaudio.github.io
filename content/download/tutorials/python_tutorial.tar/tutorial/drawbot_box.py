import random

def init():
    global seed # our global seed
    seed = random.Random()

    # globall object list, will contain the instances of the objects we create
    global objectList
    objectList = [] # its an array so we can loop though it

    for x in range(10): # create 100 objects and store in the list
        x = seed.randint(0, 300)
        y = seed.randint(0, 300)
        deltax= seed.randint(-10, 10)
        deltay= seed.randint(-10, 10)
        #r,g,b = seed.random(),seed.random(),seed.random()
        color = seed.random(),seed.random(),seed.random(), seed.random()
        thisone = BouncingRect(x, y, deltax, deltay, color) # instanciate the class
        objectList.append( thisone ) # append to the list


class Simple:
    """ a very simple class we wont use uin the example
    """
    def __init__(self, x, y):
        self.x = 0
        self.y = y
    def render(self):
        oval(self.x, self.y, 100,100)


class BouncingRect:
    """ drawns a circle that boujnces against a given limits changin its direction
        properties of the class start with 'p' and arguments of functions start with 'a'
        this is just a convention that its good to differenciate but its up to you to
        decide how to name things. Its good practice though.
    """
    def __init__(self, ax, ay, adeltax, adeltay, acolor):
        # few initalisation arguments
        self.px = ax # put them into the properties to remember
        self.py = ay
        self.pdeltax = adeltax
        self.pdeltay = adeltay
        self.pcolor = acolor

    def step(self):
        # this func its called from drawbot loop function so it we want the balls
        # to be animated we have to call this function. Its like the exitframe in director
        self.px += self.pdeltax # uoadte the location
        self.py += self.pdeltay

        if self.px > 300 or self.px < 1: # check if we are within limits
            self.pdeltax = -self.pdeltax # if not then change direcction. bounce
        if self.py > 400 or self.py < 1:
            self.pdeltay = -self.pdeltay

        fill(self.pcolor[0], self.pcolor[1], self.pcolor[2], self.pcolor[2]) # set color to draw
        oval(self.px, self.py, 100,100) # draw it in new location


def loop():
    # the loop
    global objectList # rememebr to declare it.
    for x in objectList: # fpor ech one in the list
        x.step() # calll its step fuinction to update their position and draw



