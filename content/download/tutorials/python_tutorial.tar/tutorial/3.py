import time

import random

r = random.Random() # must init random seed

print r.random()
print r.randint(10, 20)

while True: # neverending loop

    print r.random(), r.randint(10, 20)

    time.sleep(0.5) # you don't need this, but otherwise it goes as fast as it can go





