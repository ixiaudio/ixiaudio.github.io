import random

def init():
    global seed # our global seed
    seed = random.Random()
    """ this is an example of how mu MUST NEVER EVER program. Just did it so that
        you understand
    """
    # few globals
    global x
    x = 0

    global y
    y = 0

    global deltax
    deltax = +10

    global deltay
    deltay = +10


def loop():
    global seed
    global x
    global deltax
    global y
    global deltay

    fill(1.0, 0.0, 0.0)
    rotate(seed.randint(-10, 10))

    #scale(seed.randint(0.5,1.5))
    #fill(random()-0.4, 0.2, 0.2, random())
    #translate(random(-5,5),random(-5,5))
    rect(x, y, 100,100)
    x += deltax
    y += deltay

    if x > 300 or x < 1:
        deltax = -deltax
    if y > 400 or y < 1:
        deltay = -deltay

    fill(1.0, 0.5, 0.0)
    oval(150, 150, 150, 100)

