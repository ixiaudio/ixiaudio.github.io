import time

class Counter:
    """ a simpler counter
    """
    def __init__(self):
        # inits the count prperty
        self.count = 0

    def add(self, delta):
        # adds a num to the count property
        self.count += delta

    def getCount(self):
        # returns the value of the count prop
        return self.count



class CounterWithMax(Counter): # inherits from Counter
    def __init__(self, max):
        Counter.__init__(self) # initalises its superclass
        self.max = max # and specilises it by extending the init def

    def checkReset(self): # and by implementing bew functions
        if self.count >= self.max:
            "print max reached!!!"
            self.count = 0
        else:
            print "not yet"




def Main():
    c = CounterWithMax(300) # init with max value to 300

    while 1:
        c.add(1) # increase by 1
        print c.getCount() #p rint count
        c.checkReset() # check if we reached max value
        time.sleep(0.01)





if __name__ == '__main__': Main()


