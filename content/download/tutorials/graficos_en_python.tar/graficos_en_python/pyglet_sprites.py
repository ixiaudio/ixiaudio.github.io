#!/usr/bin/env python

# copyright ixi audio
# license GPL

import pyglet
pyglet.options['debug_gl'] = False # increase performace when using opengl. disables error checking

from pyglet.gl import *
from random import Random


seed = Random()
batch = pyglet.graphics.Batch()
fps_display = pyglet.clock.ClockDisplay()
stack = []



# opening the window
try:
    config = Config(sample_buffers=1, samples=4, depth_size=16, double_buffer=True,)
    window = pyglet.window.Window( 800, 600, resizable=True, config=config)
except pyglet.window.NoSuchConfigException:
    print "applying safe configuration"
    window = pyglet.window.Window(resizable=True)

    


class Void( pyglet.sprite.Sprite ) :
    
    img = pyglet.image.load('void.gif')

    def __init__(self) :
        pyglet.sprite.Sprite.__init__(self, self.img, batch=batch)

        self.vDelta = seed.randint(-3, -1)
        
        self.rotDelta = 0
        while self.rotDelta == 0 :
             self.rotDelta = seed.randint(-3, 3)

        self.x = seed.random() * window.width
        self.y = seed.random() * window.height
##        print self.position

    def run(self) :
        self.rotation += self.rotDelta # spin
        
        if self.y + self.vDelta < 0 : #back to top
            self.y = window.height - 10
        else :
            self.y = self.y + self.vDelta





def setup() :
    # this should make the alpha work ...
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

    glClearColor(seed.random(), seed.random(), seed.random(), 0) # background color
    
    for s in xrange(100) :
        stack.append( Void() ) 



def update(dt) : 
    for s in stack :
        s.run()



    
@window.event
def on_draw() :
    window.clear() # equivalente a glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    fps_display.draw()
    batch.draw()




setup()
pyglet.clock.schedule_interval(update, 1/15.)
# main loop
pyglet.app.run()

