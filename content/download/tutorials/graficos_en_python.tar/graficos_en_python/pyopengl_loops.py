#!/usr/bin/env python

# copyright ixi audio
# license GPL

from OpenGL.GL import *
from OpenGL.GLU import *

import pygame
from pygame.locals import *


class Graph :
    def __init__( self, x, y ) :
        self.x = x
        self.y = y
        
    def render( self  ) :
        glPushMatrix()
        glTranslatef( self.x, self.y, 0 ) # go to mouseloc
        glBegin( GL_QUADS )
        glColor3f( 0.8,0,0)  #
        glVertex3f( -6, 6, 0 ) #left top
        glVertex3f( 6, 6, 0 )
        glVertex3f( 6, -6, 0 )
        glVertex3f( -6, -6, 0 )
        glEnd()
        glPopMatrix()	


def main( size=(800, 600) ) :

    from random import Random
    seed = Random()

    stack = []
    
    for o in xrange(100) :
        x = seed.random() * size[0]
        y = seed.random() * size[1]
        stack.append( Graph( x, y ) ) 
    
    running = 1

    pygame.init()
    pygame.display.set_mode( size, OPENGL | DOUBLEBUF )

    glMatrixMode(GL_PROJECTION)

    glOrtho(0, size[0],  size[1], 0, 1, 0) 

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

    glClearColor(1.0, 1.0, 1.0, 0.0)
    glClearDepth(1.0)

    clock = pygame.time.Clock()

    while running :  # endless loop
        clock.tick(12) # fps
        
        # deal with events
        for e in pygame.event.get(): 
            if e.type == MOUSEMOTION:
                x,y = pygame.mouse.get_pos()
            elif e.type == QUIT :
                running = 0
            elif e.type == KEYDOWN:          
                if e.key == K_ESCAPE :
                    running = 0
                        
        glClearDepth( 1.0 )
        glClearColor(1, 1, 1, 1) #bg color
        glClear(GL_COLOR_BUFFER_BIT)

        for o in stack :
            o.x = seed.random() * size[0]
            o.y = seed.random() * size[1]
##        for o in stack :
            o.render()

        pygame.display.flip()



if __name__ == '__main__' : main()

