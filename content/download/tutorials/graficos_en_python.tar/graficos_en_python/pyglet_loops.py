#!/usr/bin/env python

# copyright ixi audio
# license GPL

import pyglet
pyglet.options[ 'debug_gl' ] = False # increase performace when using opengl. disables error checking

from pyglet.gl import *

from random import Random
seed = Random()

##global batch, stack, width, height, fps_display, count, window

batch = pyglet.graphics.Batch()
stack = [] 
width, height = 800,600
count = 0
fps_display = pyglet.clock.ClockDisplay()

mousex = mousey = 0

selected = None



try:
##    config = Config(sample_buffers=1, samples=4, depth_size=16, double_buffer=True, vsync=0)
    config = Config(double_buffer=True, depth_size=16,)
    window = pyglet.window.Window(width, height, resizable=True, config=config)
except pyglet.window.NoSuchConfigException:
    print "applying safe configuration"
    window = pyglet.window.Window(resizable=True,double_buffer=True)


        

class Test(object) :
    w = 10
    group = pyglet.graphics.OrderedGroup(1)  # layers
    
    def __init__( self, z) :

        self.v = batch.add(
            4, pyglet.gl.GL_QUADS, self.group,
            ( 'v2f/stream', (0,0,0,0,0,0,0,0) ),
            ( 'c3B/static', (255, 0, 0) *4 )
            )
        self.update()

    def update(self) :
        x = seed.random() * window.width
        y = seed.random() * window.height
        self.v.vertices = \
            x-self.w, y-self.w, \
            x+self.w, y-self.w, \
            x+self.w, y+self.w, \
            x-self.w, y+self.w



def setup() :
    glClearColor(1, 1, 1, 1)
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    
    for i in xrange(100) :
        stack.append( Test(i) )
    

@window.event
def on_draw() :
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    fps_display.draw()
    batch.draw() # PYGLET batch
    

    
def update(dt) :
    for o in stack :
        o.update()





setup()
##pyglet.clock.schedule(update) # more CPU
pyglet.clock.schedule_interval(update, 1/15.)
pyglet.app.run()

#OLD Style loop
##pyglet.clock.set_fps_limit(30) # bad idea! takes more CPU
##while True:
##    pyglet.clock.tick()
##    for window in pyglet.app.windows:
##        window.switch_to()
##        window.dispatch_events()
##        window.dispatch_event('on_draw')
##        window.flip()

