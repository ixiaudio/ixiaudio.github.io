#!/usr/bin/env python

# copyright ixi audio
# license GPL

import pygame
from pygame.locals import *



def main() :
    """ this function is called when the program starts.
    it initializes everything it needs, then runs in
    a loop until the function returns.
    """
    #init pygame and screen
    pygame.init()
    pygame.display.set_caption('pygame example')
    screen = pygame.display.set_mode((640, 460), HWSURFACE | DOUBLEBUF)

    #create the backgound surface where we will draw
    background = pygame.Surface( screen.get_size() )
    background = background.convert()
    background.fill((255, 255, 255)) #initial bg color

    #paste bg into the screen to avoid back flash on first frame
    screen.blit( background, (0, 0) )
    pygame.display.flip()

    #init framerate clock
    clock = pygame.time.Clock()

    #Main Loop
    while 1 :
            
        clock.tick(20) # set fps 
        background.fill((255, 255, 255)) # clear buffer with bg color
        
        #Handle Input Events
        for event in pygame.event.get():
            # Key Events ...#
            if event.type == QUIT:
                return # this quits the main loop
            elif event.type == KEYDOWN :
                print 'key pressed', event.key
            if event.key == K_ESCAPE:
                return # this quits the main loop

        # drawing something on the background
        pygame.draw.circle(background, (255,0,0), pygame.mouse.get_pos(), 25, 0)
        pygame.draw.polygon(background, (255,0,100), ((200,200), (250, 220), (260, 290), (210, 300)), 3)
        pygame.draw.rect( background, (100, 100, 0), (400, 200, 100, 100), 0 )
        pygame.draw.ellipse(background, (100, 100, 255), (200, 100, 50, 100), 0)
        
        #draw everything
        screen.blit(background, (0, 0)) # swap buffers
        pygame.display.flip() # update




if __name__ == '__main__': main()

