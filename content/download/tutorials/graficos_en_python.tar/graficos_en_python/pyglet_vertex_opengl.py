#!/usr/bin/env python

# copyright ixi audio
# license GPL

import pyglet
pyglet.options[ 'debug_gl' ] = False # increase performace when using opengl. disables error checking

from pyglet.gl import *

from random import Random
seed = Random()

width, height = 800,600
fps_display = pyglet.clock.ClockDisplay()
w = 20 # rect width
mousex = mousey = 0 # for the mouse


try:
    # Try and create a window with multisampling (antialiasing)
    config = Config(sample_buffers=1, samples=4, 
                    depth_size=16, double_buffer=True,)
    window = pyglet.window.Window(width, height, resizable=True, config=config)
except pyglet.window.NoSuchConfigException:
    # Fall back to no multisampling for old hardware
    print "applying safe configuration"
    window = pyglet.window.Window(resizable=True)

        
        

@window.event
def on_mouse_motion(x, y, dx, dy):
    global  mousex, mousey
    mousex, mousey = x,y

@window.event
def on_draw() :
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    fps_display.draw()
    
##    pyglet.graphics.draw(4, pyglet.gl.GL_QUADS,  ('v2f', v) )
    
    glPushMatrix()
    glTranslatef( mousex, mousey , 0 ) # go to mouseloc
    glBegin( GL_QUADS )
    glColor3f( 1,1,1)  #
    glVertex3f( -w, w, 0 ) #left top
    glVertex3f( w, w, 0 )
    glVertex3f( w, -w, 0 )
    glVertex3f( -w, -w, 0 )
    glEnd()
    glPopMatrix()	



pyglet.app.run()
