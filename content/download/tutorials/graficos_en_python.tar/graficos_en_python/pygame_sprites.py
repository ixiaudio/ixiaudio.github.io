#!/usr/bin/env python

# copyright ixi audio
# license GPL


#Import Modules
import os, pygame
from pygame.locals import *
from random import Random


#int and define globals here
g = Random()

####################################################

#functions to create our resources

# LOAD IMGS #
def load_image(name, colorkey=None):
    try:
        image = pygame.image.load(name)
    except pygame.error, message:
        print 'Cannot load image:', name
        raise SystemExit, message

    image = image.convert()

    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0,0))
        image.set_colorkey(colorkey, RLEACCEL)
        
    return image, image.get_rect()




####################################################




class Void( pygame.sprite.Sprite ):

    bounds = 0
    
    def __init__(self):
        "init object, declare and set properties"
        Void.bounds = pygame.display.get_surface().get_rect() # classprop needs to be int after display is on
        pygame.sprite.Sprite.__init__(self, self.containers) #call Sprite initializer
        self.image, self.rect = load_image('void.gif', -1)

        self.rotDelta = 0
        self.dizzy = 0
        self.original = self.image  #store pos
    
        self.vDelta = g.randint(-3, -1)
        while (self.rotDelta == 0):
             self.rotDelta = g.randint(-3, 3)

        self.rect.midtop = (g.randint(0, 640), g.randint(0, 460)) # randomloc on screen

    def update(self) :
        self.spin()
        self.run()
    
    def spin(self):
        "rotates image"
        center = self.rect.center
        self.dizzy = self.dizzy + self.rotDelta
        if self.dizzy >= 360:
            self.dizzy = 0
            self.image = self.original
        else:
            rotate = pygame.transform.rotate
            self.image = rotate(self.original, self.dizzy)
        self.rect = self.image.get_rect()
        self.rect.center = center

 
    def run(self):
        loc = self.rect.center[1]
        loc = loc - self.vDelta
        if loc > self.bounds.bottom: #back to top
            loc = self.bounds.top + 10
        self.rect.center = self.rect.center[0], loc




####################################################




def main():

    #Initialize Everything
    pygame.init() 
    screen = pygame.display.set_mode( (640, 460) )
    pygame.display.set_caption('voooooooids...')

    #Create The Backgound
    background = pygame.Surface(screen.get_size())
    background = background.convert()
    randcolor = g.randint(0, 255), g.randint(0, 255), g.randint(0, 255)
    background.fill(  randcolor ) # random color each time
    

    #Display The Background
    screen.blit(background, (0, 0))
    pygame.display.flip()
    
    #Prepare Game Objects
    clock = pygame.time.Clock()

    voids = pygame.sprite.Group()
    Void.containers = voids

##    voidlist = [] #to store sprites, we wont use it really
    
    for i in range(100) :
        Void()
##        voidlist.append(Void())

    allsprites = pygame.sprite.RenderPlain((voids))

    while 1: #endless loop
        clock.tick(20) 

        #Handle Input Events
        for event in pygame.event.get():
            if event.type == QUIT:
                return
                
        allsprites.update()

        #Draw Everything
        screen.blit(background, (0, 0))
        allsprites.draw(screen)
        pygame.display.flip()

        

#Game Over

####################################################


#this calls the 'main' function when this script is executed
if __name__ == '__main__': main()

