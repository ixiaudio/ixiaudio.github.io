#!/usr/bin/env python

# copyright ixi audio
# license GPL


from OpenGL.GL import *
from OpenGL.GLU import *

import pygame
from pygame.locals import *



def main():
    size = 640, 480
    x = y = r = 0 # for the mouse
    running = 1

    pygame.init()
    pygame.display.set_mode(size, OPENGL | DOUBLEBUF)

    glMatrixMode(GL_PROJECTION)

    glOrtho(0, size[0],  size[1], 0, 1, 0) # this is how it should be as far as i understand

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

    glClearColor(1.0, 1.0, 1.0, 0.0)
    glClearDepth(1.0)

    clock = pygame.time.Clock()

    while running :  # lendless loop
        clock.tick(15) # fps

        r += 10 # rotation
        
        # deal with events
        for e in pygame.event.get(): 
            if e.type == MOUSEMOTION :
                x,y = pygame.mouse.get_pos()
            elif e.type == QUIT :
                running = 0
            elif e.type == KEYDOWN:           # keydown events
                if e.key == K_ESCAPE :
                    running = 0
                        
        # prepare for drawing next frame
        glClearDepth(1.0)
        glClearColor(1,1,1,1) #bg color
        glClear(GL_COLOR_BUFFER_BIT) #| GL_DEPTH_BUFFER_BIT)

        glPushMatrix()
                
        glTranslate(x,y, 0) # go to mouseloc
        glRotatef(r, 0, 0, 1)
        glBegin(GL_QUADS)
        glColor3f(0.8,0,0) #
        glVertex3f(-36, 36, 0) #left top
        glVertex3f(36, 36, 0)
        glVertex3f(36, -36, 0)
        glVertex3f(-36, -36, 0)
        glEnd()

        glPopMatrix()	

        pygame.display.flip() # swap buffers



if __name__ == '__main__': main()


