#!/usr/bin/env python

# copyright ixi audio
# license GPL

import pygame
from pygame.locals import *



def main():
    """ this function is called when the program starts.
	it initializes everything it needs, then runs in
	a loop until the function returns.
    """
    #init pygame and screen
    pygame.init()
    pygame.display.set_caption('pygame example')
    screen = pygame.display.set_mode((640, 460), HWSURFACE | DOUBLEBUF)

    #create the backgound surface where we will draw
    background = pygame.Surface( screen.get_size() )
    background = background.convert()
    background.fill((0, 255, 255)) #initial bg color

    #paste bg into the screen to avoid back flash on first frame
    screen.blit( background, (0, 0) )
    pygame.display.flip()

    #init framerate clock
    clock = pygame.time.Clock()

    # this prints all locals which include events name constants
    print '-+'*20
    print dir(pygame.locals) 
    print '-+'*20
    
    #Main Loop
    while 1 :
        
        clock.tick(20) # set fps this while runs
        background.fill((0, 255, 255)) # clear buffer with bg color
    
        #Handle Input Events
        for event in pygame.event.get():
            # Key Events ...#
            if event.type == QUIT:# quit window button pressed
                return # this quits the main loop
            elif event.type == KEYDOWN :
                print 'key pressed', event.key
                if event.key == K_ESCAPE: # escape key
                    return # this quits the main loop
                
            # Mouse events ... #
            elif event.type == MOUSEBUTTONDOWN:
                print 'mouse down', pygame.mouse.get_pos(), pygame.mouse.get_pressed()
            elif event.type == MOUSEBUTTONUP:
                print 'mouse up', pygame.mouse.get_pos(), pygame.mouse.get_pressed()
            elif event.type == MOUSEMOTION:
                print 'mouse moved', pygame.mouse.get_pos(), pygame.mouse.get_pressed()
                
            # JOYSTICK events ... #
            elif event.type == JOYAXISMOTION: # 7
                self.joyAxisMotion(event.joy, event.axis, event.value)
            elif event.type == JOYBALLMOTION: # 8
                self.joyBallMotion(event.joy, event.ball, event.value)
            elif event.type == JOYHATMOTION: # 9
                self.joyHatMotion(event.joy, event.hat, event.value)
            elif event.type == JOYBUTTONDOWN: # 10
                self.joyButtonDown(event.joy, event.button)
            elif event.type == JOYBUTTONUP: # 11
                self.joyButtonUp(event.joy, event.button)
                
            # ... and so on ...
            
        #now Draw Everything
        screen.blit(background, (0, 0)) # swap buffers
        pygame.display.flip() # update



####################################################
#this calls the 'main' function when this script is executed
if __name__ == '__main__': main()

