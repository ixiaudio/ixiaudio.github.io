#!/usr/bin/env python

# copyright ixi audio
# license GPL

import pyglet
pyglet.options[ 'debug_gl' ] = False # increase performace when using opengl. disables error checking

from pyglet.gl import *

from random import Random
seed = Random()


##global batch, stack, width, height, fps_display, count, window

batch = pyglet.graphics.Batch()
stack = [] 
width, height = 800,600
count = 0
fps_display = pyglet.clock.ClockDisplay()



try:
    config = Config(sample_buffers=1, samples=4, depth_size=16, double_buffer=True,)
    window = pyglet.window.Window(width, height, resizable=True, config=config)
except pyglet.window.NoSuchConfigException:
    print "applying safe configuration"
    window = pyglet.window.Window(resizable=True)


    

class Rect(object) :
    w = 10
    group = pyglet.graphics.OrderedGroup(1)  # layers
    
    def __init__( self, z) :
        self.x = self.y = 0
        self.v = batch.add(
            4, pyglet.gl.GL_QUADS, self.group,
            ( 'v2f/stream', (0,0,0,0,0,0,0,0) ),
            ( 'c3B/static', (255, 0, 0) *4 )
##            ( 'c3B/static', (255, 0, 0,  255, 0, 0 , 255, 0, 0, 255, 0, 0) )
            )
        self.update()
##        self.v.delete()

    def update(self) :
        x = seed.random() * width
        y = seed.random() * height
        self.x, self.y = x,y
        self.v.vertices =    x-self.w, y-self.w, \
                     x+self.w, y-self.w, \
                     x+self.w, y+self.w, \
                     x-self.w, y+self.w
        
    



def setup() :
    glClearColor(1, 1, 1, 1)
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    
    for i in xrange(30) :
        stack.append( Rect(i) )

    

@window.event
def on_draw() :
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    fps_display.draw()
    batch.draw() # PYGLET batch 



def update(dt) :
    for o in stack : 
        o.update()



setup()
pyglet.clock.schedule_interval(update, 1./12)
pyglet.app.run()

