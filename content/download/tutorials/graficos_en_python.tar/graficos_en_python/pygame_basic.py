#!/usr/bin/env python

# copyright ixi audio
# license GPL

import pygame
from pygame.locals import *



def main():
    """ this function is called when the program starts.
	it initializes everything it needs, then runs in
	a loop until the function returns.
    """
    #init pygame and screen
    pygame.init()
    pygame.display.set_caption('pygame example')
    
    # window size, rendering method and double buffer
    screen = pygame.display.set_mode( (640, 460), HWSURFACE | DOUBLEBUF )

    #create the backgound surface where we will draw
    background = pygame.Surface( screen.get_size() )
    background = background.convert()
    
    #clean it, paste into the screen to avoid back flash on first frame
    background.fill((255, 0, 255)) #initial bg color
    screen.blit( background, (0, 0) )
    pygame.display.flip()

    #init framerate clock
    clock = pygame.time.Clock()

    #main loop
    while 1 :
        clock.tick(20) # set fps 
        background.fill((255, 0, 255)) # clear buffer with bg color
        #handle input events
        for event in pygame.event.get():
            if event.type == QUIT :
                return # quits the main loop and the app

        # drawing a circle on the background
        color = (255,0,0) # tuple RGB
        loc = pygame.mouse.get_pos() # tuple x, y
        radius = 20
        width = 3
        pygame.draw.circle(background, color, loc, radius, width)
        # all pygame drawing functions here :
        # http://pygame.org/docs/ref/draw.html

        #update screen
        screen.blit(background, (0, 0)) # swap buffers
        pygame.display.flip() # update

    print 'ok, quiting app'



####################################################
#this calls the 'main' function when this script is executed
if __name__ == '__main__': main()

