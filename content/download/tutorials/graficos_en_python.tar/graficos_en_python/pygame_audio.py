#!/usr/bin/env python

# copyright ixi audio
# license GPL


import pygame
from pygame.locals import *



def main():
    """ this function is called when the program starts.
	it initializes everything it needs, then runs in
	a loop until the function returns.
    """
    #init pygame and screen
    pygame.init()
    # name of the window
    pygame.display.set_caption('pygame example')
    # window size, rendering method and double buffer
    size = (640, 460)
    screen = pygame.display.set_mode( size, HWSURFACE | DOUBLEBUF )

    #create the backgound surface where we will draw
    background = pygame.Surface( screen.get_size() )
    background = background.convert()
    
    #clean it, paste into the screen to avoid back flash on first frame
    background.fill((255, 0, 255)) #initial bg color
    screen.blit( background, (0, 0) )
    pygame.display.flip()

    #init framerate clock
    clock = pygame.time.Clock()
    

    # audio
    pygame.mixer.init(44100) # frequency

    sound = pygame.mixer.Sound('beep1.aiff')
    channel = pygame.mixer.find_channel()

    #main loop
    while 1 :
        clock.tick(20) # set fps this while runs
	background.fill((255, 0, 255)) # clear buffer with bg color
	
	#handle input events
	for event in pygame.event.get():
	    if event.type == QUIT :
		return # quits the main loop and the app
            elif event.type == MOUSEBUTTONDOWN :
                channel.play(sound, -1) # -1 to loop forever
            elif event.type == MOUSEBUTTONUP :
                channel.stop()
            elif event.type == MOUSEMOTION :
                x,y = pygame.mouse.get_pos()
                # we can do panning like this
                volume = float(y)/screen.get_size()[1] #between 0 and 1
                pan =  float(x)/screen.get_size()[0]  #between 0 and 1
                volume = 1 - volume # to get 0 on bottom and 1 on top
                pan = 1 - pan # to get 0 left and 1 right
                lvol = (volume * pan)/1. # need to calculte the volume for each channel from vol and pan
                rvol = volume - lvol
                channel.set_volume(lvol, rvol)

        #update screen
	screen.blit(background, (0, 0)) # swap buffers
	pygame.display.flip() # update

    print 'ok, quiting app'


##    channel.get_volume()
##    channel.stop()
##    pygame.mixer.pause()
##    pygame.mixer.unpause()
##    pygame.mixer.stop()
    

    

####################################################
#this calls the 'main' function when this script is executed
if __name__ == '__main__': main()

