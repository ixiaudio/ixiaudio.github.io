#!/usr/bin/env python

# copyright ixi audio
# license GPL

import pyglet
pyglet.options['debug_gl'] = False # increase performace when using opengl. disables error checking

from pyglet.gl import *


# some globals
mousex = mousey = 0 # to store mouseloc
fps_display = pyglet.clock.ClockDisplay()




# opening the window
try:
    config = Config(sample_buffers=1, samples=4, depth_size=16, double_buffer=True,)
    window = pyglet.window.Window( 800, 600, resizable=True, config=config)
except pyglet.window.NoSuchConfigException:
    print "applying safe configuration"
    window = pyglet.window.Window(resizable=True)




# defining events
@window.event
def on_mouse_motion(x, y, dx, dy):
    print 'mouse moved', x, y, dx, dy

@window.event
def on_mouse_drag(x, y, dx, dy,  buttons, modifiers) :
    global mousex,mousey
    mousex, mousey = x,  y # reverse Y axis
    print 'mouse dragged', x, y, dx, dy,  buttons, modifiers

@window.event
def on_mouse_press(x, y, button, modifiers) :
    print 'mouse down', x, y, button, modifiers

@window.event
def on_mouse_release(x, y, button, modifiers) :
    print 'mouse up', x, y, button, modifiers
    
@window.event
def on_draw() :
    window.clear() # equivalente a glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    fps_display.draw()




# main loop
pyglet.app.run()

