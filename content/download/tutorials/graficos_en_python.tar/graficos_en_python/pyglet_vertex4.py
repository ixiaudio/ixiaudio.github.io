#!/usr/bin/env python

# copyright ixi audio
# license GPL

import pyglet
pyglet.options[ 'debug_gl' ] = False # increase performace when using opengl. disables error checking

from pyglet.gl import *

from random import Random
seed = Random()

width, height = 800,600
fps_display = pyglet.clock.ClockDisplay()

w = 20 # rect width

v = pyglet.graphics.vertex_list(4,
    ( 'v2i', (0,0,0,0,0,0,0,0) ),
    ( 'c4B', (0, 255, 255, 255) * 4)
)



try:
    # Try and create a window with multisampling (antialiasing)
    config = Config(sample_buffers=1, samples=4, 
                    depth_size=16, double_buffer=True,)
    window = pyglet.window.Window(width, height, resizable=True, config=config)
except pyglet.window.NoSuchConfigException:
    # Fall back to no multisampling for old hardware
    print "applying safe configuration"
    window = pyglet.window.Window(resizable=True)

        
        

@window.event
def on_mouse_motion(x, y, dx, dy):
    global v
    v.vertices =  x-w, y-w,    \
             x+w, y-w,  \
             x+w, y+w,  \
             x-w, y+w


@window.event
def on_draw() :
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    fps_display.draw()
    v.draw(pyglet.gl.GL_QUADS)

   



pyglet.app.run()
