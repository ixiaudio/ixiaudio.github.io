#!/usr/bin/env python

# copyright ixi audio
# license GPL

import sys
import math
from PyQt4 import QtCore, QtGui, QtOpenGL


from OpenGL.GL import *


x = y = 0 # to store mouse loc


class GLWidget(QtOpenGL.QGLWidget):
    def __init__(self):
        QtOpenGL.QGLWidget.__init__(self, None)

        self.size = 800, 600

        # init framerate
        timer = QtCore.QTimer(self)
        self.connect(timer, QtCore.SIGNAL("timeout()"), self.updateGL  )
        timer.start(20)

##    def initializeGL(self):
##        width, height = 573, 800
##        side = min(width, height)
##        glViewport((width - side) / 2, (height - side) / 2, side, side)
##
##        glMatrixMode(GL_PROJECTION)
##        glLoadIdentity()
##        glFrustum(-1.0, +1.0, -1.0, 1.0, 5.0, 60.0)
##        glMatrixMode(GL_MODELVIEW)
##        glLoadIdentity()
##        glTranslated(0.0, 0.0, -40.0)
##        
####        initgraphics
##        glEnable(GL_LIGHTING)
##        glEnable(GL_LIGHT0)
##        glEnable(GL_DEPTH_TEST)
##
##        glEnable(GL_NORMALIZE)

    def paintGL(self):
        # engine.render()
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)


        glLoadIdentity()                                    # Reset The View

##        # Move Right 1.5 units and into the screen 6.0 units.
##        glTranslatef(1.5, 0.0, -6.0)
##        glColor3f(1, 0.5, 0.2)          # color, as rgb, each component accepts values between 0 and 1. so 1,1,1 is white, 1,0,0 is red and so on ...
##        glBegin(GL_QUADS)                   # Start drawing a 4 sided polygon
##        glVertex3f(-1.0, 1.0, 0.0)          # Top Left
##        glVertex3f(1.0, 1.0, 0.0)           # Top Right
##        glVertex3f(1.0, -1.0, 0.0)          # Bottom Right
##        glVertex3f(-1.0, -1.0, 0.0)         # Bottom Left
##        glEnd()

        glPushMatrix()
        glTranslate(x,y, 0) # go to mouseloc
        glBegin(GL_QUADS)
        glColor3f(0.8,0,0) #
        glVertex3f(-10, 10, 0) #left top
        glVertex3f(10, 10, 0)
        glVertex3f(10, -10, 0)
        glVertex3f(-10, -10, 0)
        glEnd()
        glPopMatrix()	
	
       # red diagonal lines from vertex of window
        glBegin(GL_LINE_LOOP)
        glColor3f(1,0,0) #
        glVertex2i(0,0)
        glVertex2i(self.size[0], self.size[1])
        glVertex2i(0, self.size[1])
        glVertex2i(self.size[0], 0)
        glVertex2i(0,0) # marquee
        glVertex2i(self.size[0], 0)
        glVertex2i(self.size[0], self.size[1])
        glVertex2i(0, self.size[1])
        glEnd() # end line loop


    def resizeGL(self, width, height):

##        side = min(width, height)
##        glViewport((width - side) / 2, (height - side) / 2, side, side)

        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
##        glFrustum(-1.0, +1.0, -1.0, 1.0, 5.0, 60.0)
        glOrtho(0, 800, 600, 0, 1, 0) 
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
##        glTranslated(0.0, 0.0, -40.0)

    # pass input event to evelt listener
    def mousePressEvent(self, event):
        print 'press event', event.x(), event.y()#, dir(event)

    def mouseMoveEvent(self, event):
        print 'mouse moved', event.x(), event.y()
        global x,y
        x,y = event.x(), event.y()

        if event.buttons() & QtCore.Qt.LeftButton:
            print 'left button',  event.x(), event.y()

        elif event.buttons() & QtCore.Qt.RightButton:
            print 'right button',  event.x(), event.y()

          




class MainWindow(QtGui.QMainWindow):
    def __init__(self):        
        QtGui.QMainWindow.__init__(self)

        self.glWidget = GLWidget()
        self.setCentralWidget(self.glWidget)

        self.createActions()
        self.createMenus()
        
        self.statusBar()
        self.setWindowTitle(self.tr("Grabber"))
        self.resize(800, 600)
        self.move(10,10)










    def renderIntoPixmap(self): 
        size = self.getSize()

        if size.isValid():
            pixmap = self.glWidget.renderPixmap(size.width(), size.height())
            self.setPixmap(pixmap)

    def grabFrameBuffer(self): 
        image = self.glWidget.grabFrameBuffer()
        self.setPixmap(QtGui.QPixmap.fromImage(image))

    def clearPixmap(self): 
        self.setPixmap(QtGui.QPixmap())

    def about(self): 
        QtGui.QMessageBox.about(self, self.tr("About Grabber"),
                self.tr("The <b>Grabber</b> example demonstrates two approaches for rendering OpenGL into a Qt pixmap."))

    def createActions(self):
        self.renderIntoPixmapAct = QtGui.QAction(self.tr("&Render into Pixmap..."), self)
        self.renderIntoPixmapAct.setShortcut(self.tr("Ctrl+R")) 
        self.connect(self.renderIntoPixmapAct, QtCore.SIGNAL("triggered()"),
                self.renderIntoPixmap)

        self.grabFrameBufferAct = QtGui.QAction(self.tr("&Grab Frame Buffer"), self)
        self.grabFrameBufferAct.setShortcut(self.tr("Ctrl+G"))
        self.connect(self.grabFrameBufferAct, QtCore.SIGNAL("triggered()"),
                self.grabFrameBuffer)

        self.clearPixmapAct = QtGui.QAction(self.tr("&Clear Pixmap"), self)
        self.clearPixmapAct.setShortcut(self.tr("Ctrl+L"))
        self.connect(self.clearPixmapAct, QtCore.SIGNAL("triggered()"), self.clearPixmap)

        self.exitAct = QtGui.QAction(self.tr("E&xit"), self)
        self.exitAct.setShortcut(self.tr("Ctrl+Q"))
        self.connect(self.exitAct, QtCore.SIGNAL("triggered()"), self, QtCore.SLOT("close()"))

        self.aboutAct = QtGui.QAction(self.tr("&About"), self)
        self.connect(self.aboutAct, QtCore.SIGNAL("triggered()"), self.about)

        self.aboutQtAct = QtGui.QAction(self.tr("About &Qt"), self) 
        self.connect(self.aboutQtAct, QtCore.SIGNAL("triggered()"), app, QtCore.SLOT("aboutQt()"))

    def createMenus(self):
        self.fileMenu = self.menuBar().addMenu(self.tr("&File"))
        self.fileMenu.addAction(self.renderIntoPixmapAct)
        self.fileMenu.addAction(self.grabFrameBufferAct)
        self.fileMenu.addAction(self.clearPixmapAct)
        self.fileMenu.addSeparator()
        self.fileMenu.addAction(self.exitAct)

        self.helpMenu = self.menuBar().addMenu(self.tr("&Help"))
        self.helpMenu.addAction(self.aboutAct)
        self.helpMenu.addAction(self.aboutQtAct)

    def createSlider(self, changedSignal, setterSlot):
        slider = QtGui.QSlider(QtCore.Qt.Horizontal)
        slider.setRange(0, 360 * 16)
        slider.setSingleStep(16)
        slider.setPageStep(15 * 16)
        slider.setTickInterval(15 * 16)
        slider.setTickPosition(QtGui.QSlider.TicksRight)

        self.connect(slider, QtCore.SIGNAL("valueChanged(int)"), setterSlot)
        self.connect(self.glWidget, changedSignal, slider, QtCore.SLOT("setValue(int)"))

        return slider

    def setPixmap(self, pixmap):
        self.pixmapLabel.setPixmap(pixmap)
        size = pixmap.size()

        if size - QtCore.QSize(1, 0) == self.pixmapLabelArea.maximumViewportSize():
            size -= QtCore.QSize(1, 0)

        self.pixmapLabel.resize(size)

    def getSize(self):
        ok = False

        text = QtGui.QInputDialog.getText(self, self.tr("Grabber"), 
                                        self.tr("Enter pixmap size:"),
                                        QtGui.QLineEdit.Normal,
                                        self.tr("%1 x %2").arg(self.glWidget.width()).arg(self.glWidget.height()))

        if ok:
            return QtCore.QSize()

        regExp = QtCore.QRegExp(self.tr("([0-9]+) *x *([0-9]+)"))

        if regExp.exactMatch(text[0]):
            width = regExp.cap(0).toInt()
            height = regExp.cap(1).toInt()
            if width > 0 and width < 2048 and height > 0 and height < 2048:
                return QtCore.QSize(width, height)

        return self.glWidget.size()


if __name__ == "__main__":
    app = QtGui.QApplication(sys.argv)
    mainWin = MainWindow()
    print 'main show'
    mainWin.show()
    print 'after main show'
    sys.exit(app.exec_())
    print 'exited'
