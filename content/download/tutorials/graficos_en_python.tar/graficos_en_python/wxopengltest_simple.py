#!/usr/bin/env python

# copyright ixi audio
# license GPL

from OpenGL.GLUT import *
from OpenGL.GLU import *
from OpenGL.GL import *
import wx
from wx import glcanvas


x = y = 0 # to store mouse loc



class FpsTimer(wx.Timer):
    def __init__(self, fps, f):
        wx.Timer.__init__(self)
        self.Start(1000./fps)
        self.f = f # function to call on notify

    def Notify(self): self.f()



class MwxFrame(wx.Frame):
    def __init__(self, parent=None, id=-1, title='frametitle', pos=(0,0), size=(20,20)):
        wx.Frame.__init__(self, parent, id, title, pos, size)
        self.SetSize(size)
       
    def structure(self, canvas):
        bodyupSizer = wx.BoxSizer(wx.VERTICAL)
        bodyupSizer.Add(canvas, 0) #wx.ALIGN_CENTER|wx.ALL, 15)
        self.SetAutoLayout(True)
        self.SetSizer(bodyupSizer)
        self.Layout()
        self.Centre()



class App(wx.App):
    
    def __init__(self, pos, size):
        wx.App.__init__(self, 0)
        self.name = "testing wxopengl"
        self.size = size
        self.pos = pos
        self.init = 0
        # correcting glcanvas size to acomodate to frame space left by other widgets
        self.frame = MwxFrame(None, -1, self.name, self.pos, self.size) #wxframe

       #print 'framesizeV, sizeV-22', self.frame.GetClientSize()[1], self.size[1]-22 

        self.canvas = glcanvas.GLCanvas(self.frame, -1, self.pos, (self.size[0], self.size[1]))
        #self.canvas = glcanvas.GLCanvas(self.frame, -1, self.pos, self.frame.GetClientSize())#self.size)
##        self.canvas.size = self.canvas.GetClientSize()
        self.canvas.Bind(wx.EVT_PAINT, self.paint)
        def void(self) : pass # a dummy function
        self.canvas.Bind(wx.EVT_ERASE_BACKGROUND, void) # dummy to avoid flash on windows
        self.canvas.Bind(wx.EVT_MOTION, self.onMouseMoved)
        
        self.glsize = self.canvas.GetSize() # passed to glOrtho
        
        print 'glsize, canvasclientsize, framesize', self.glsize, self.canvas.GetClientSize(), self.frame.GetClientSize()
        
        self.frame.structure(self.canvas)
        self.frame.Show()

	
    def onMouseMoved(self, evt):
        global x,y
        x,y = evt.GetPosition()

    def initGL(self):
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()

        glOrtho(0, self.glsize[0], self.glsize[1], 0, 1, 0) # map gl units to pixels
##        glOrtho(-1, self.glsize[0], self.glsize[1]+1, 0, 1, 0) # map gl units to pixels

##        glOrtho(0, self.glsize[0], self.glsize[1], 0, 1, 0) # map gl units to pixels
##        glOrtho(-1, self.glsize[0], self.glsize[1]+1, 0, 1, 0) # map gl units to pixels
##        glOrtho(0, self.glsize[0], self.glsize[1], 0, 1, 0) # map gl units to pixels
##        glOrtho(-1, self.glsize[0], self.glsize[1]+1, -1, 1, 0) # map gl units to pixels

        glMatrixMode(GL_MODELVIEW)
        # now init timer if done previously there is an error on Linux
        self.t = FpsTimer(20, self.canvas.Refresh)
        self.init = True


    def paint(self,event):
        # print x,y
        
        wx.PaintDC(self.canvas)
        self.canvas.SetCurrent()
        if not self.init : self.initGL()
        glClearDepth(1.0)
        glClearColor(1,1,1, 1) #bg color
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
	
        glPushMatrix()
        glTranslate(x,y, 0) # go to mouseloc
        glBegin(GL_QUADS)
        glColor3f(0.8,0,0) #
        glVertex3f(-10, 10, 0) #left top
        glVertex3f(10, 10, 0)
        glVertex3f(10, -10, 0)
        glVertex3f(-10, -10, 0)
        glEnd()
        glPopMatrix()	
	
       # red diagonal lines from vertex of window
        glBegin(GL_LINE_LOOP)
        glColor3f(1,0,0) #
        glVertex2i(0,0)
        glVertex2i(self.size[0], self.size[1])
        glVertex2i(0, self.size[1])
        glVertex2i(self.size[0], 0)
        glVertex2i(0,0) # marquee
        glVertex2i(self.size[0], 0)
        glVertex2i(self.size[0], self.size[1])
        glVertex2i(0, self.size[1])
        glEnd() # end line loop
				
        self.canvas.SwapBuffers()


def main():
    app = App((0,0), (800,600)) # pos and size
    app.MainLoop()


if __name__ == '__main__':
    main()


