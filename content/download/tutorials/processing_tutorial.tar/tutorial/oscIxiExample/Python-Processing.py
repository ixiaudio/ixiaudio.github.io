import time, random
import osc


def printStuff(*msg):
    """ deals with "print" tagged OSC addresses
    """
    print "printing in the printStuff function ", msg
    print "the oscaddress is ", msg[0][0]
    print "the value is ", msg[0][2]
    

osc.init()

seed = random.Random()

inSocket = osc.createListener('127.0.0.1', 57120) # in this case just using one socket

osc.bind(printStuff, "/testA")


while 1: # main loop
    time.sleep(0.5) #every half sec
    osc.getOSC(inSocket) # listen to incomming OSC in this socket
    
    r = seed.randint(0,255)
    g = seed.randint(0,255)
    b = seed.randint(0,255)
    osc.sendMsg("/testB", [r,g,b], "127.0.0.1", 12000) # send normal msg to a specific ip and port

    


