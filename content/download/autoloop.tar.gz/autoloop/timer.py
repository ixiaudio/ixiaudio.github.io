

try:
    import pyext
except:
    print "ERROR: This script must be loaded by the PD/Max pyext external"



import time


#################################################################


#class ex1:
class ex1(pyext._class):
    """Example of a simple class which receives messages and prints to the console"""

    # number of inlets and outlets
    _inlets = 3
    _outlets = 3

    def __init__(self):
	#self.rec = 0 # recording on or off
	self.sequ = 1,1,1,1,1,1,1,1 # sampling time sequence in 4 float secs
	self.sequIndex = 0
	self.layer = 0 # next layer to be used
	self.layersStatus = 1,1,1,1,1,1,1,1 # snd layersStatus active or not
	self.timeOut = 0
	self.start = 0

    def startT(self):
	self.timeOut = time.time() + self.sequ[self.sequIndex] # remember

    def nextTimeOut(self):
	"""calc now next layer and seq to use"""
	# sequences
	self.sequIndex +=1
	if self.sequIndex > len(self.sequ)-1 : self.sequIndex = 0 # reset in end
	while self.sequ[self.sequIndex] == 0 : # it was off
	    self.sequIndex +=1 # try next
	    if self.sequIndex > len(self.sequ)-1 : self.sequIndex = 0 # reset in end

	self.startT() # calc next timeout

	# layersStatus
	if max(self.layersStatus) == 0 : print 'no snd layersStatus active' ; return # fuck off
	self.layer +=1
	if self.layer > len(self.layersStatus)-1 : self.layer = 0 # reset in end (7)
	while self.layersStatus[self.layer] == 0 : # it was off
	    self.layer +=1 # try next
	    if self.layer > len(self.layersStatus)-1 : self.layer = 0 # reset in end

	# broadcast to PD
	#print self.layer, self.sequ[self.sequIndex]
	self._outlet(1, self.layer) # next layer
	self._outlet(2, self.sequIndex) #    and next seq
	self._outlet(3, self.sequ[self.sequIndex]) #currently recording for this long


### PyExt inlets and outlet message handlers ###

    def bang_1(self): # loop
	if not self.start : # init timer
	    self.startT()
	    self.start = 1

	if time.time() >= self.timeOut :
	    self.nextTimeOut()

    def list_2(self, *l) : self.layersStatus = l #; print self.layersStatus  # set layersStatus
    def list_3(self, *l) : self.sequ = l #; print self.sequ # set sequ




