

try:
    import pyext
except:
    print "ERROR: This script must be loaded by the PD/Max pyext external"

import random
seed = random.Random()

#################################################################


class rpitch(pyext._class):
	"""Example of a simple class which receives messages and prints to the console"""

	# number of inlets and outlets
	_inlets=4
	_outlets=1
	
	state = 0
	pmin = 0.5
	prange = 2
	floatyes = 1
	
	def int_1(self,n):
		self.state = n
		#print self.state
	def bang_1(self):
		#print 'bang'
		self.calcRandPitch()

	def float_2(self, n):
		self.pmin = n
	def int_2(self, n):
		self.pmin = n

	def float_3(self, n):
		self.prange = n
	def int_3(self, n):
		self.prange= n
		
	def int_4(self, n):
		self.floatyes = n
		
    	def calcRandPitch(self):
	    if self.state: 
	    	#if self.pmin==0 and self.pmax==1:
		#	self._outlet(1, seed.random())
		#	return
		#r = seed.randint(self.pmin, self.pmax)
		#if self.floatyes : r += seed.random()
		r = seed.uniform(self.pmin, self.pmin+self.prange)
		if not self.floatyes : r = int(r)
		if r == 0 : r = 1# avoid 0
		self._outlet(1, r) # number
		#self._outlet(1, n) # layer to pass number to
		
		

