"""
SuperCollider OSC sommunication.
"""

from controller import Controller
from tools import decode
