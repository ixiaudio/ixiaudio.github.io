ARHeadtracker
-------------

This application is part of the AmbIEM package and licensed under GPL. It uses the ARToolKit (http://www.hitl.washington.edu/artoolkit/) for visual pattern recognition using a simple webcam. The postion of the pattern is calculated and sent over Open Sound Control to SuperCollider3. Using the SC3 class ARHeadtracker you can easily access the data and incorporate it in your application. 

Compilation:
You will need to download ARToolKit in order to compile the command line tool. If you run into problems with your camera, please refer to ARToolKits FAQ. 

Running:
start the ARHeadtracker tool from command line (at the level of the Projectfile) and then run SC3 and step through the Help file.

Have fun!
--
Christopher Frauenberger [frauenberger@iem.at]